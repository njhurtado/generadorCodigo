/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para crear un objeto Lugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccCrearLugar extends DComandoAccion {
	private static final long serialVersionUID = 787603974L; 

	/** Objeto de transporte de Lugar */
	protected DLugarTO toLugar;
	/** Llave primaria de Lugar */
	protected DLugarPKTO pkLugar;
	/** Atributos de Lugar */
	protected DLugarAttTO attLugar;

	/**
	 * Inicializa la creaci�n de Lugar.
	 * @param toLugar Objeto de Transporte de Lugar
	 */
	public void inicializar(DLugarTO toLugar) {
		isOk = false;
		this.toLugar = toLugar;
		if (toLugar != null) {
			pkLugar = this.toLugar.getPK();
			attLugar = this.toLugar.getAtt();
		}
	}


	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdAccCrearLugar();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite crear un objeto Lugar";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los parametros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		parametros.put(this.getClass().getName()+":validar:toLugar",toLugar);
		parametros.put(this.getClass().getName()+":validar:attLugar",attLugar);
		parametros.put(this.getClass().getName()+":validar:pkLugar",pkLugar);
		parametros.put(this.getClass().getName()+":validar:pkLugar.getIdeLugar()",pkLugar.getIdeLugar());
		parametros.put(this.getClass().getName()+":validar:attLugar.getIdeTipoLugar()",attLugar.getIdeTipoLugar());
		parametros.put(this.getClass().getName()+":validar:attLugar.getNomTipoLugar()",attLugar.getNomTipoLugar());
		parametros.put(this.getClass().getName()+":validar:attLugar.getIdeUsuarioCambio()",attLugar.getIdeUsuarioCambio());
		parametros.put(this.getClass().getName()+":validar:attLugar.getFecCambio()",attLugar.getFecCambio());
		validarParametros("Crear",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�etro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdAccCrearLugar) {
			DCmdAccCrearLugar copia = (DCmdAccCrearLugar) comando;
			copia.toLugar = toLugar;
			copia.pkLugar = pkLugar;
			copia.attLugar = attLugar;
		}
	}
}
