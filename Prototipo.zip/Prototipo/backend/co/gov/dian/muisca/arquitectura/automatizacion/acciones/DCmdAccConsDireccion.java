/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar un objeto Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsDireccion extends DComandoAccion {
	private static final long serialVersionUID = -696411487L; 

	/** Objeto de transporte de Direccion */
	protected DDireccionTO toDireccion;
	/** Llave primaria de Direccion */
	protected DDireccionPKTO pkDireccion;
	/** Atributos de Direccion */
	protected DDireccionAttTO attDireccion;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkDireccion Llave primaria de Direccion
	 */
	public void inicializar(DDireccionPKTO pkDireccion) {
		isOk = false;
		toDireccion = null;
		attDireccion = null;
		this.pkDireccion = pkDireccion;
	}

	/**
	 * Devuelve el objeto Direccion que se haya consultado.
	 * @return Un objeto DDireccionTO
	 */
	public DDireccionTO getDireccion() {
		return toDireccion;
	}

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdAccConsDireccion();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite consultar un objeto Direccion";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		parametros.put(this.getClass().getName()+":validar:pkDireccion",pkDireccion);
		parametros.put(this.getClass().getName()+":validar:pkDireccion.getIdeDireccion()",pkDireccion.getIdeDireccion());
		validarParametros("Consulta",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdAccConsDireccion) {
			DCmdAccConsDireccion copia = (DCmdAccConsDireccion) comando;
			copia.toDireccion = toDireccion;
			copia.pkDireccion = pkDireccion;
			copia.attDireccion = attDireccion;
		}
	}
}
