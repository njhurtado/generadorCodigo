/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para los atributos de TipoDocumento.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DTipoDocumentoAttTO implements IDTO {
	private static final long serialVersionUID = 2139082954L; 

	// Atributos
	private java.lang.String nomTipoDocumento;
	private java.lang.Long ideUsuarioCambio;
	private java.sql.Timestamp fecCambio;

	/**
	 * Construye un nuevo DTipoDocumentoAttTO por defecto.
	 */
	public DTipoDocumentoAttTO() { }

	/**
	 * Construye un nuevo DTipoDocumentoAttTO con los atributos.
	 * @param nomTipoDocumento java.lang.String
	 * @param ideUsuarioCambio java.lang.Long
	 * @param fecCambio java.sql.Timestamp
	 */
	public DTipoDocumentoAttTO(java.lang.String nomTipoDocumento, java.lang.Long ideUsuarioCambio, java.sql.Timestamp fecCambio) {
		setNomTipoDocumento(nomTipoDocumento);
		setIdeUsuarioCambio(ideUsuarioCambio);
		setFecCambio(fecCambio);
	}

	/**
	 * Devuelve el valor de nomTipoDocumento.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomTipoDocumento() {
		return nomTipoDocumento;
	}

	/**
	 * Establece el valor de nomTipoDocumento.
	 * @param nomTipoDocumento El nuevo valor de nomTipoDocumento
	 */
	public void setNomTipoDocumento(java.lang.String nomTipoDocumento) {
		this.nomTipoDocumento = nomTipoDocumento;
	}

	/**
	 * Devuelve el valor de ideUsuarioCambio.
	 * @return Un objeto java.lang.Long
	 */
	public java.lang.Long getIdeUsuarioCambio() {
		return ideUsuarioCambio;
	}

	/**
	 * Establece el valor de ideUsuarioCambio.
	 * @param ideUsuarioCambio El nuevo valor de ideUsuarioCambio
	 */
	public void setIdeUsuarioCambio(java.lang.Long ideUsuarioCambio) {
		this.ideUsuarioCambio = ideUsuarioCambio;
	}

	/**
	 * Devuelve el valor de fecCambio.
	 * @return Un objeto java.sql.Timestamp
	 */
	public java.sql.Timestamp getFecCambio() {
		return fecCambio;
	}

	/**
	 * Establece el valor de fecCambio.
	 * @param fecCambio El nuevo valor de fecCambio
	 */
	public void setFecCambio(java.sql.Timestamp fecCambio) {
		this.fecCambio = fecCambio;
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("nomTipoDocumento", getNomTipoDocumento());
		builder.append("ideUsuarioCambio", getIdeUsuarioCambio());
		builder.append("fecCambio", getFecCambio());
		return builder.toString();
	}
}
