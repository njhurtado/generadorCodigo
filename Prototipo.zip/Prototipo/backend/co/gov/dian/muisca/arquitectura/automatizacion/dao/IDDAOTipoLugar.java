/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarTO;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para TipoLugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public interface IDDAOTipoLugar extends IDDAO {
	static final int CONSULTAR_POR_PK = 0;
	static final int CREAR = 1;
	static final int ACTUALIZAR = 2;
	static final int ELIMINAR = 3;
	static final int CONSULTA_GENERICA = 4;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkTipoLugar Llave primaria de TipoLugar
	 */
	void inicializarConsultarPorPK(DTipoLugarPKTO pkTipoLugar);

	/**
	 * Inicializa la creaci�n de TipoLugar.
	 * @param toTipoLugar Objeto de Transporte de TipoLugar
	 */
	void inicializarCrear(DTipoLugarTO toTipoLugar);

	/**
	 * Inicializa la actualizaci�n de TipoLugar.
	 * @param toTipoLugar Objeto de Transporte de TipoLugar
	 */
	void inicializarActualizar(DTipoLugarTO toTipoLugar);

	/**
	 * Inicializa la eliminaci�n de TipoLugar.
	 * @param pkTipoLugar Llave primaria de TipoLugar
	 */
	void inicializarEliminar(DTipoLugarPKTO pkTipoLugar);

	/**
	 * Inicializa la eliminaci�n de TipoLugar.
	 * @param attTipoLugar Atributos de TipoLugar
	 */
	void inicializarConsultaGenerica(DTipoLugarTO toTipoLugar);

	/**
	 * Devuelve el objeto TipoLugar que se haya consultado.
	 * @return Un objeto DTipoLugarTO
	 */
	DTipoLugarTO getTipoLugar();

	/**
	 * Devuelve la colecci�n de objetos TipoLugar que se hayan consultado.
	 * @return Un Collection con objetos DTipoLugarTO
	 */
	Collection<DTipoLugarTO> getColeccionTipoLugar();
}
