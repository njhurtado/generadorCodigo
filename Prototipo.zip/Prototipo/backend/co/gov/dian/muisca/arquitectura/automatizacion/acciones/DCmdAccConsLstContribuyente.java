/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoPKTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar objetos Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsLstContribuyente extends DComandoAccion {
	private static final long serialVersionUID = -951238151L; 
	
	public static final int CONSULTAR_POR_TIPODOCUMENTO = 0;

	protected static final int CONSULTA_GENERICA = 1;

	/** Llave primaria de TipoDocumento */
	protected DTipoDocumentoPKTO pkTipoDocumento;

	protected DContribuyenteTO toContribuyente;


	/** Tipo de operaci�n de consulta */
	protected int tipoOperacion = -1;
	/** Colecci�n de objetos DContribuyenteTO */
	protected Collection<DContribuyenteTO> objetosContribuyente;

	/**
	 * Inicializa la consulta por TipoDocumento.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	public void inicializarConsultarPorTipoDocumento(DTipoDocumentoPKTO pkTipoDocumento) {
		isOk = false;
		tipoOperacion = CONSULTAR_POR_TIPODOCUMENTO;
		this.pkTipoDocumento = pkTipoDocumento;
		objetosContribuyente = null;
	}


	/**
	 * Inicializa la consulta gen�rica de Contribuyente.
	 * @param attContribuyente Atributos de Contribuyente
	 */
	public void inicializarConsultaGenerica(DContribuyenteTO toContribuyente) {
		tipoOperacion = CONSULTA_GENERICA;
		this.toContribuyente = toContribuyente;

	}

	/**
	 * Devuelve la colecci�n de objetos Contribuyente que se hayan consultado.
	 * @return Un Collection con objetos DContribuyenteTO
	 */
	public Collection<DContribuyenteTO> getColeccionContribuyente() {
		return objetosContribuyente;
	}

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdAccConsLstContribuyente();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite consultar objetos Contribuyente";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (tipoOperacion) {
			case CONSULTAR_POR_TIPODOCUMENTO:
				parametros.put(this.getClass().getName()+":validar:pkTipoDocumento",pkTipoDocumento);
				parametros.put(this.getClass().getName()+":validar:pkTipoDocumento.getIdeTipoDocumento()",pkTipoDocumento.getIdeTipoDocumento());
				break;

			case CONSULTA_GENERICA:
				parametros.put(this.getClass().getName()+":validar:toContribuyente",toContribuyente);
				break;


			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos Contribuyente"), getMensajeOperInvalida());
		}
		validarParametros("Listar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdAccConsLstContribuyente) {
			DCmdAccConsLstContribuyente copia = (DCmdAccConsLstContribuyente) comando;
			copia.tipoOperacion = tipoOperacion;
			copia.pkTipoDocumento = pkTipoDocumento;
			copia.objetosContribuyente = objetosContribuyente;
			copia.toContribuyente = toContribuyente;
		}
	}
}
