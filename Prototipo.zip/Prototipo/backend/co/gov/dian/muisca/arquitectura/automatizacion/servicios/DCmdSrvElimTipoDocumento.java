/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoPKTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para eliminar un objeto TipoDocumento.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvElimTipoDocumento extends DComandoServicioInterno {
	private static final long serialVersionUID = 1725481745L; 

	/** Llave primaria de TipoDocumento */
	protected DTipoDocumentoPKTO pkTipoDocumento;

	/**
	 * Inicializa la eliminaci�n de TipoDocumento.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	public void inicializar(DTipoDocumentoPKTO pkTipoDocumento) {
		this.pkTipoDocumento = pkTipoDocumento;
	}

	/**
	 * Ejecuta el comando de servicio.
	 * @throws DExcepcion Si ocurre alg�n error al realizar la
	 * la eliminaci�n de TipoDocumento
	 */
	protected void ejecutarComando() throws DExcepcion {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdSrvElimTipoDocumento();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite eliminar un objeto TipoDocumento";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		parametros.put(this.getClass().getName()+":validar:pkTipoDocumento",pkTipoDocumento);
		parametros.put(this.getClass().getName()+":validar:pkTipoDocumento.getIdeTipoDocumento()",pkTipoDocumento.getIdeTipoDocumento());
		validarParametros("Eliminar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdSrvElimTipoDocumento) {
			DCmdSrvElimTipoDocumento copia = (DCmdSrvElimTipoDocumento) comando;
			copia.pkTipoDocumento = pkTipoDocumento;
		}
	}
}
