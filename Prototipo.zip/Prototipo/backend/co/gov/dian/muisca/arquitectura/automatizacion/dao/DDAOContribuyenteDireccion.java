/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.sql.*;
import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.*;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.general.persistencia.dao.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.dataset.*;
import co.gov.dian.muisca.arquitectura.mensajes.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para ContribuyenteDireccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDAOContribuyenteDireccion extends DDAO implements IDDAOContribuyenteDireccion {
	/** colecci�n de objetos DContribuyenteDireccionTO */
	private Collection<DContribuyenteDireccionTO> objetosContribuyenteDireccion;
	/** Objeto de transporte de ContribuyenteDireccion */
	private DContribuyenteDireccionTO toContribuyenteDireccion;
	/** Llave primaria de ContribuyenteDireccion */
	private DContribuyenteDireccionPKTO pkContribuyenteDireccion;
	/** Atributos de ContribuyenteDireccion */
	private DContribuyenteDireccionAttTO attContribuyenteDireccion;
	/** Llave primaria de Contribuyente */
	private DContribuyentePKTO pkContribuyente;
	/** Llave primaria de Direccion */
	private DDireccionPKTO pkDireccion;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkContribuyenteDireccion Llave primaria de ContribuyenteDireccion
	 */
	public void inicializarConsultarPorPK(DContribuyenteDireccionPKTO pkContribuyenteDireccion) {
		setTipoOperacion(CONSULTAR_POR_PK);
		this.pkContribuyenteDireccion = pkContribuyenteDireccion;
	}

	/**
	 * Inicializa la consulta por Contribuyente.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	public void inicializarConsultarPorContribuyente(DContribuyentePKTO pkContribuyente) {
		setTipoOperacion(CONSULTAR_POR_CONTRIBUYENTE);
		this.pkContribuyente = pkContribuyente;
	}

	/**
	 * Inicializa la consulta por Direccion.
	 * @param pkDireccion Llave primaria de Direccion
	 */
	public void inicializarConsultarPorDireccion(DDireccionPKTO pkDireccion) {
		setTipoOperacion(CONSULTAR_POR_DIRECCION);
		this.pkDireccion = pkDireccion;
	}

	/**
	 * Inicializa la creaci�nn de ContribuyenteDireccion.
	 * @param toContribuyenteDireccion Objeto de Transporte de ContribuyenteDireccion
	 */
	public void inicializarCrear(DContribuyenteDireccionTO toContribuyenteDireccion) {
		setTipoOperacion(CREAR);
		this.toContribuyenteDireccion = toContribuyenteDireccion;
		if (toContribuyenteDireccion != null) {
			pkContribuyenteDireccion = this.toContribuyenteDireccion.getPK();
			attContribuyenteDireccion = this.toContribuyenteDireccion.getAtt();
		}
	}

	/**
	 * Inicializa la actualizaci�n de ContribuyenteDireccion.
	 * @param toContribuyenteDireccion Objeto de Transporte de ContribuyenteDireccion
	 */
	public void inicializarActualizar(DContribuyenteDireccionTO toContribuyenteDireccion) {
		setTipoOperacion(ACTUALIZAR);
		this.toContribuyenteDireccion = toContribuyenteDireccion;
		if (toContribuyenteDireccion != null) {
			pkContribuyenteDireccion = this.toContribuyenteDireccion.getPK();
			attContribuyenteDireccion = this.toContribuyenteDireccion.getAtt();
		}
	}

	/**
	 * Inicializa la eliminaci�n de ContribuyenteDireccion.
	 * @param pkContribuyenteDireccion Llave primaria de ContribuyenteDireccion
	 */
	public void inicializarEliminar(DContribuyenteDireccionPKTO pkContribuyenteDireccion) {
		setTipoOperacion(ELIMINAR);
		this.pkContribuyenteDireccion = pkContribuyenteDireccion;
	}

	/**
	 * Inicializa la consulta gen�rica de ContribuyenteDireccion.
	 * @param attContribuyenteDireccion Atributos de ContribuyenteDireccion
	 */
	public void inicializarConsultaGenerica(DContribuyenteDireccionTO toContribuyenteDireccion) {
		setTipoOperacion(CONSULTA_GENERICA);

		this.toContribuyenteDireccion = toContribuyenteDireccion;
		if (toContribuyenteDireccion != null) {
			pkContribuyenteDireccion = this.toContribuyenteDireccion.getPK();
			attContribuyenteDireccion = this.toContribuyenteDireccion.getAtt();
		}
	}

	/**
	 * Devuelve las sentencias sql a ejecutar, dependiendo del tipo de operaci�n a realizar.
	 * @return Un Map de Strings con la relaci�n de sentencias sql
	 */
	public Map<String, String> getSentenciasSQL() {
		Map<String, String> m = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();
		switch (getTipoOperacion()) {
			case CREAR:
				sql.append("insert into CONTRIBUYENTE_DIRECCION")
					.append(" (IDE_CONTRIBUYENTE, IDE_DIRECCION, IDE_USUARIO_CAMBIO, FEC_CAMBIO)")
					.append(" VALUES (:IDE_CONTRIBUYENTE, :IDE_DIRECCION, :IDE_USUARIO_CAMBIO, :FEC_CAMBIO)");
				m.put("sentencia1", sql.toString());
				break;
			case ACTUALIZAR:
				sql.append("update CONTRIBUYENTE_DIRECCION")
					.append(" set IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO, FEC_CAMBIO=:FEC_CAMBIO")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE and IDE_DIRECCION=:IDE_DIRECCION");
				m.put("sentencia1", sql.toString());
				break;
			case ELIMINAR:
				sql.append("delete from CONTRIBUYENTE_DIRECCION")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE and IDE_DIRECCION=:IDE_DIRECCION");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_PK:
				sql.append("select * from CONTRIBUYENTE_DIRECCION")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE and IDE_DIRECCION=:IDE_DIRECCION");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTA_GENERICA:
				sql.append("select * from CONTRIBUYENTE_DIRECCION where ")
					.append(generarFiltroGenerico());
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_CONTRIBUYENTE:
				sql.append("select * from CONTRIBUYENTE_DIRECCION")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_DIRECCION:
				sql.append("select * from CONTRIBUYENTE_DIRECCION")
					.append(" where IDE_DIRECCION=:IDE_DIRECCION");
				m.put("sentencia1", sql.toString());
				break;
		}
		return m;
	}


	/**
	 * obtenerConsultaGenerica
	 *
	 * @return StringBuffer
	 */
	private String generarFiltroGenerico() {
		StringBuffer condiciones = new StringBuffer();
		String y = " AND ";
		boolean append = false;

		if (pkContribuyenteDireccion != null) {

			if (pkContribuyenteDireccion.getIdeContribuyente() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE");
				append = true;

			}
			if (pkContribuyenteDireccion.getIdeDireccion() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_DIRECCION=:IDE_DIRECCION");
				append = true;

			}
		}

		if (attContribuyenteDireccion != null) {

			if (attContribuyenteDireccion.getIdeUsuarioCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO");
				append = true;

			}
			if (attContribuyenteDireccion.getFecCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("FEC_CAMBIO=:FEC_CAMBIO");
				append = true;

			}
		}

		return condiciones.toString();
	}

	/**
	 * Asigna los valores no nulos de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresGenericos(DSentenciaSQL unaSentencia) throws SQLException {
		if (pkContribuyenteDireccion != null) {
			if (pkContribuyenteDireccion.getIdeContribuyente() != null) {
				unaSentencia.setLong("IDE_CONTRIBUYENTE", pkContribuyenteDireccion.getIdeContribuyente());
			}
			if (pkContribuyenteDireccion.getIdeDireccion() != null) {
				unaSentencia.setLong("IDE_DIRECCION", pkContribuyenteDireccion.getIdeDireccion());
			}
		}

		if (attContribuyenteDireccion != null) {
			if (attContribuyenteDireccion.getIdeUsuarioCambio() != null) {
				unaSentencia.setLong("IDE_USUARIO_CAMBIO", attContribuyenteDireccion.getIdeUsuarioCambio());
			}
			if (attContribuyenteDireccion.getFecCambio() != null) {
				unaSentencia.setTimestamp("FEC_CAMBIO", attContribuyenteDireccion.getFecCambio());
			}
		}
	}

	/**
	 * Guarda los datos de ContribuyenteDireccion.
	 * @return @return Un int con el n�mero de registros guardados
	 * @throws SQLException Si ocurre un error de base de datos al guardar
	 */
	public int guardar() throws SQLException {
		switch (getTipoOperacion()) {
			case CREAR:
				return crear();
			case ACTUALIZAR:
				return actualizar();
		}
		return -1;
	}

	/**
	 * Elimina registros de ContribuyenteDireccion.
	 * @return Un int con el n�mero de registros eliminados
	 * @throws SQLException Si ocurre un error de base de datos al eliminar
	 */
	public int eliminar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		return sentencia.getRegistrosAfectados();
	}

	/**
	 * Consulta los datos de ContribuyenteDireccion.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	public IDDataSet consultar() throws SQLException {
		switch (getTipoOperacion()) {
			case CONSULTAR_POR_PK:
				return consultarPorPK();
			case CONSULTAR_POR_CONTRIBUYENTE:
				return consultarPorContribuyente();
			case CONSULTAR_POR_DIRECCION:
				return consultarPorDireccion();
			case CONSULTA_GENERICA:
				return consultaGenerica();
		}
		return null;
	}

	/**
	 * Crea un registro de ContribuyenteDireccion.
	 * @return Un int con el n�mero de registros creados
	 * @throws SQLException Si ocurre un error de base de datos al crear
	 */
	private int crear() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha creado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� crear m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de ContribuyenteDireccion.
	 * @return Un int con el n�mero de registros actualizados
	 * @throws SQLException Si ocurre un error de base de datos al actualizar
	 */
	private int actualizar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha actualizado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� actualizar m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de ContribuyenteDireccion.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorPK() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarContribuyenteDireccion(resultado);
		return resultado;
	}

	/**
	 * Consulta gen�rica de los datos de ContribuyenteDireccion.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultaGenerica() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresGenericos(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosContribuyenteDireccion(resultado);
		return resultado;
	}

	/**
	 * Consulta por Contribuyente.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorContribuyente() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		sentencia.setInt("IDE_CONTRIBUYENTE", pkContribuyente.getIdeContribuyente());
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosContribuyenteDireccion(resultado);
		return resultado;
	}

	/**
	 * Consulta por Direccion.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorDireccion() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		sentencia.setLong("IDE_DIRECCION", pkDireccion.getIdeDireccion());
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosContribuyenteDireccion(resultado);
		return resultado;
	}

	/**
	 * Asigna los valores para pk en una sentencia SQL.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresPK(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setLong("IDE_CONTRIBUYENTE", pkContribuyenteDireccion.getIdeContribuyente());
		unaSentencia.setLong("IDE_DIRECCION", pkContribuyenteDireccion.getIdeDireccion());
	}

	/**
	 * Asigna todos los valores de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresObjeto(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setLong("IDE_USUARIO_CAMBIO", attContribuyenteDireccion.getIdeUsuarioCambio());
		unaSentencia.setTimestamp("FEC_CAMBIO", attContribuyenteDireccion.getFecCambio());
	}

	/**
	 * Construye un objeto ContribuyenteDireccion con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private void cargarContribuyenteDireccion(IDDataSet resultado) throws SQLException {
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		toContribuyenteDireccion = completarContribuyenteDireccion(resultado);
	}

	/**
	 * Construye objetos ContribuyenteDireccion con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar los objetos
	 */
	private void cargarObjetosContribuyenteDireccion(IDDataSet resultado) throws SQLException {
		objetosContribuyenteDireccion = new ArrayList<DContribuyenteDireccionTO>();
		toContribuyenteDireccion = null;
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		do {
			DContribuyenteDireccionTO objeto = completarContribuyenteDireccion(resultado);
			objetosContribuyenteDireccion.add(objeto);
		} while (resultado.siguiente());
		resultado.primero();
	}

	/**
	 * Construye un objeto ContribuyenteDireccion con base en el data set.
	 * El data set debe contener datos en la posici�n actual.
	 * @param resultado Contenedor de los datos
	 * @return Un ContribuyenteDireccion
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private DContribuyenteDireccionTO completarContribuyenteDireccion(IDDataSet resultado) throws SQLException {
		// Conformar el objeto PK
		DContribuyenteDireccionPKTO pk = new DContribuyenteDireccionPKTO();
		//java.lang.Long
		pk.setIdeContribuyente(resultado.getLongWrapper("IDE_CONTRIBUYENTE"));
		//java.lang.Long
		pk.setIdeDireccion(resultado.getLongWrapper("IDE_DIRECCION"));

		// Conformar el objeto Att
		DContribuyenteDireccionAttTO att = new DContribuyenteDireccionAttTO();
		//java.lang.Long
		att.setIdeUsuarioCambio(resultado.getLongWrapper("IDE_USUARIO_CAMBIO"));
		//java.sql.Timestamp
		att.setFecCambio((Timestamp)resultado.getValorPorNombre("FEC_CAMBIO"));

		// Conformar el TO
		DContribuyenteDireccionTO to = new DContribuyenteDireccionTO();
		to.setPK(pk);
		to.setAtt(att);
		return to;
	}

	/**
	 * Devuelve el objeto ContribuyenteDireccion que se haya consultado.
	 * @return Un objeto DContribuyenteDireccionTO
	 */
	public DContribuyenteDireccionTO getContribuyenteDireccion() {
		return toContribuyenteDireccion;
	}

	/**
	 * Devuelve la colecci�n de objetos ContribuyenteDireccion que se hayan consultado.
	 * @return Un Collection con objetos DContribuyenteDireccionTO
	 */
	public Collection<DContribuyenteDireccionTO> getColeccionContribuyenteDireccion() {
		return objetosContribuyenteDireccion;
	}

	/**
	 * Indica si el DAO es de ejecuci�n libre.
	 * @return true si es de ejecuci�n libre; false de lo contrario
	 */
	public boolean isEjecucionLibre() {
		return false;
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado por el administrador de persistencia.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 * @todo COMPLEMENTAR
	 */
	public boolean validar() throws DValidarExcepcion {
		DManipuladorMensaje manipulador;
		String operacion = null;
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (getTipoOperacion()) {
			case CREAR: operacion = "la creaci�n"; break;
			case ACTUALIZAR: operacion = "la actualizaci�n"; break;
			case ELIMINAR: operacion = "la eliminaci�n"; break;
			case CONSULTAR_POR_PK: operacion = "la consulta"; break;
			case CONSULTA_GENERICA: operacion = "la consulta"; break;
			case CONSULTAR_POR_CONTRIBUYENTE: operacion = "la consulta"; break;
			case CONSULTAR_POR_DIRECCION: operacion = "la consulta"; break;
		}

		if (operacion == null) {
			manipulador = new DManipuladorMensaje(IDArqMensajes.ME_OPER_INVALIDA);
			String mensaje = manipulador.getMensaje();
			throw new DValidarExcepcion(mensaje, mensaje);
		}

		if (tipoOperacion == CREAR || tipoOperacion == ACTUALIZAR) {
			parametros.put(this.getClass().getName()+":validar:toContribuyenteDireccion",toContribuyenteDireccion);
			parametros.put(this.getClass().getName()+":validar:pkContribuyenteDireccion",pkContribuyenteDireccion);
			parametros.put(this.getClass().getName()+":validar:attContribuyenteDireccion",attContribuyenteDireccion);

			parametros.put(this.getClass().getName()+":validar:pkContribuyenteDireccion.getIdeContribuyente()",pkContribuyenteDireccion.getIdeContribuyente());
			parametros.put(this.getClass().getName()+":validar:pkContribuyenteDireccion.getIdeDireccion()",pkContribuyenteDireccion.getIdeDireccion());
			parametros.put(this.getClass().getName()+":validar:attContribuyenteDireccion.getIdeUsuarioCambio()",attContribuyenteDireccion.getIdeUsuarioCambio());
			parametros.put(this.getClass().getName()+":validar:attContribuyenteDireccion.getFecCambio()",attContribuyenteDireccion.getFecCambio());
		}

		if (tipoOperacion == CONSULTAR_POR_PK || tipoOperacion == ELIMINAR) {
			parametros.put(this.getClass().getName()+":validar:pkContribuyenteDireccion",pkContribuyenteDireccion);
			parametros.put(this.getClass().getName()+":validar:pkContribuyenteDireccion.getIdeContribuyente()",pkContribuyenteDireccion.getIdeContribuyente());
			parametros.put(this.getClass().getName()+":validar:pkContribuyenteDireccion.getIdeDireccion()",pkContribuyenteDireccion.getIdeDireccion());
		}

		if (tipoOperacion == CONSULTA_GENERICA) {
			parametros.put(this.getClass().getName()+":validar:toContribuyenteDireccion",toContribuyenteDireccion);
		}

		if (tipoOperacion == CONSULTAR_POR_CONTRIBUYENTE) {
			parametros.put(this.getClass().getName()+":validar:pkContribuyente.getIdeContribuyente()",pkContribuyente.getIdeContribuyente());
		}
		if (tipoOperacion == CONSULTAR_POR_DIRECCION) {
			parametros.put(this.getClass().getName()+":validar:pkDireccion.getIdeDireccion()",pkDireccion.getIdeDireccion());
		}

		validarParametros(operacion,parametros);
		return true;
	}
}
