/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteDireccionPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteDireccionTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyentePKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionPKTO;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para ContribuyenteDireccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public interface IDDAOContribuyenteDireccion extends IDDAO {
	static final int CONSULTAR_POR_PK = 0;
	static final int CONSULTAR_POR_CONTRIBUYENTE = 1;
	static final int CONSULTAR_POR_DIRECCION = 2;
	static final int CREAR = 3;
	static final int ACTUALIZAR = 4;
	static final int ELIMINAR = 5;
	static final int CONSULTA_GENERICA = 6;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkContribuyenteDireccion Llave primaria de ContribuyenteDireccion
	 */
	void inicializarConsultarPorPK(DContribuyenteDireccionPKTO pkContribuyenteDireccion);

	/**
	 * Inicializa la consulta por Contribuyente.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	void inicializarConsultarPorContribuyente(DContribuyentePKTO pkContribuyente);

	/**
	 * Inicializa la consulta por Direccion.
	 * @param pkDireccion Llave primaria de Direccion
	 */
	void inicializarConsultarPorDireccion(DDireccionPKTO pkDireccion);

	/**
	 * Inicializa la creaci�n de ContribuyenteDireccion.
	 * @param toContribuyenteDireccion Objeto de Transporte de ContribuyenteDireccion
	 */
	void inicializarCrear(DContribuyenteDireccionTO toContribuyenteDireccion);

	/**
	 * Inicializa la actualizaci�n de ContribuyenteDireccion.
	 * @param toContribuyenteDireccion Objeto de Transporte de ContribuyenteDireccion
	 */
	void inicializarActualizar(DContribuyenteDireccionTO toContribuyenteDireccion);

	/**
	 * Inicializa la eliminaci�n de ContribuyenteDireccion.
	 * @param pkContribuyenteDireccion Llave primaria de ContribuyenteDireccion
	 */
	void inicializarEliminar(DContribuyenteDireccionPKTO pkContribuyenteDireccion);

	/**
	 * Inicializa la eliminaci�n de ContribuyenteDireccion.
	 * @param attContribuyenteDireccion Atributos de ContribuyenteDireccion
	 */
	void inicializarConsultaGenerica(DContribuyenteDireccionTO toContribuyenteDireccion);

	/**
	 * Devuelve el objeto ContribuyenteDireccion que se haya consultado.
	 * @return Un objeto DContribuyenteDireccionTO
	 */
	DContribuyenteDireccionTO getContribuyenteDireccion();

	/**
	 * Devuelve la colecci�n de objetos ContribuyenteDireccion que se hayan consultado.
	 * @return Un Collection con objetos DContribuyenteDireccionTO
	 */
	Collection<DContribuyenteDireccionTO> getColeccionContribuyenteDireccion();
}
