/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.sql.*;
import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.general.persistencia.dao.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.dataset.*;
import co.gov.dian.muisca.arquitectura.mensajes.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para TipoLugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDAOTipoLugar extends DDAO implements IDDAOTipoLugar {
	/** colecci�n de objetos DTipoLugarTO */
	private Collection<DTipoLugarTO> objetosTipoLugar;
	/** Objeto de transporte de TipoLugar */
	private DTipoLugarTO toTipoLugar;
	/** Llave primaria de TipoLugar */
	private DTipoLugarPKTO pkTipoLugar;
	/** Atributos de TipoLugar */
	private DTipoLugarAttTO attTipoLugar;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkTipoLugar Llave primaria de TipoLugar
	 */
	public void inicializarConsultarPorPK(DTipoLugarPKTO pkTipoLugar) {
		setTipoOperacion(CONSULTAR_POR_PK);
		this.pkTipoLugar = pkTipoLugar;
	}

	/**
	 * Inicializa la creaci�nn de TipoLugar.
	 * @param toTipoLugar Objeto de Transporte de TipoLugar
	 */
	public void inicializarCrear(DTipoLugarTO toTipoLugar) {
		setTipoOperacion(CREAR);
		this.toTipoLugar = toTipoLugar;
		if (toTipoLugar != null) {
			pkTipoLugar = this.toTipoLugar.getPK();
			attTipoLugar = this.toTipoLugar.getAtt();
		}
	}

	/**
	 * Inicializa la actualizaci�n de TipoLugar.
	 * @param toTipoLugar Objeto de Transporte de TipoLugar
	 */
	public void inicializarActualizar(DTipoLugarTO toTipoLugar) {
		setTipoOperacion(ACTUALIZAR);
		this.toTipoLugar = toTipoLugar;
		if (toTipoLugar != null) {
			pkTipoLugar = this.toTipoLugar.getPK();
			attTipoLugar = this.toTipoLugar.getAtt();
		}
	}

	/**
	 * Inicializa la eliminaci�n de TipoLugar.
	 * @param pkTipoLugar Llave primaria de TipoLugar
	 */
	public void inicializarEliminar(DTipoLugarPKTO pkTipoLugar) {
		setTipoOperacion(ELIMINAR);
		this.pkTipoLugar = pkTipoLugar;
	}

	/**
	 * Inicializa la consulta gen�rica de TipoLugar.
	 * @param attTipoLugar Atributos de TipoLugar
	 */
	public void inicializarConsultaGenerica(DTipoLugarTO toTipoLugar) {
		setTipoOperacion(CONSULTA_GENERICA);

		this.toTipoLugar = toTipoLugar;
		if (toTipoLugar != null) {
			pkTipoLugar = this.toTipoLugar.getPK();
			attTipoLugar = this.toTipoLugar.getAtt();
		}
	}

	/**
	 * Devuelve las sentencias sql a ejecutar, dependiendo del tipo de operaci�n a realizar.
	 * @return Un Map de Strings con la relaci�n de sentencias sql
	 */
	public Map<String, String> getSentenciasSQL() {
		Map<String, String> m = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();
		switch (getTipoOperacion()) {
			case CREAR:
				sql.append("insert into TIPO_LUGAR")
					.append(" (IDE_TIPO_LUGAR, NOM_TIPO_LUGAR, IDE_USUARIO_CAMBIO, FEC_CAMBIO)")
					.append(" VALUES (:IDE_TIPO_LUGAR, :NOM_TIPO_LUGAR, :IDE_USUARIO_CAMBIO, :FEC_CAMBIO)");
				m.put("sentencia1", sql.toString());
				break;
			case ACTUALIZAR:
				sql.append("update TIPO_LUGAR")
					.append(" set NOM_TIPO_LUGAR=:NOM_TIPO_LUGAR, IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO, FEC_CAMBIO=:FEC_CAMBIO")
					.append(" where IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case ELIMINAR:
				sql.append("delete from TIPO_LUGAR")
					.append(" where IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_PK:
				sql.append("select * from TIPO_LUGAR")
					.append(" where IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTA_GENERICA:
				sql.append("select * from TIPO_LUGAR where ")
					.append(generarFiltroGenerico());
				m.put("sentencia1", sql.toString());
				break;
		}
		return m;
	}


	/**
	 * obtenerConsultaGenerica
	 *
	 * @return StringBuffer
	 */
	private String generarFiltroGenerico() {
		StringBuffer condiciones = new StringBuffer();
		String y = " AND ";
		boolean append = false;

		if (pkTipoLugar != null) {

			if (pkTipoLugar.getIdeTipoLugar() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR");
				append = true;

			}
		}

		if (attTipoLugar != null) {

			if (attTipoLugar.getNomTipoLugar() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_TIPO_LUGAR=:NOM_TIPO_LUGAR");
				append = true;

			}
			if (attTipoLugar.getIdeUsuarioCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO");
				append = true;

			}
			if (attTipoLugar.getFecCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("FEC_CAMBIO=:FEC_CAMBIO");
				append = true;

			}
		}

		return condiciones.toString();
	}

	/**
	 * Asigna los valores no nulos de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresGenericos(DSentenciaSQL unaSentencia) throws SQLException {
		if (pkTipoLugar != null) {
			if (pkTipoLugar.getIdeTipoLugar() != null) {
				unaSentencia.setInt("IDE_TIPO_LUGAR", pkTipoLugar.getIdeTipoLugar());
			}
		}

		if (attTipoLugar != null) {
			if (attTipoLugar.getNomTipoLugar() != null) {
				unaSentencia.setString("NOM_TIPO_LUGAR", attTipoLugar.getNomTipoLugar());
			}
			if (attTipoLugar.getIdeUsuarioCambio() != null) {
				unaSentencia.setLong("IDE_USUARIO_CAMBIO", attTipoLugar.getIdeUsuarioCambio());
			}
			if (attTipoLugar.getFecCambio() != null) {
				unaSentencia.setTimestamp("FEC_CAMBIO", attTipoLugar.getFecCambio());
			}
		}
	}

	/**
	 * Guarda los datos de TipoLugar.
	 * @return @return Un int con el n�mero de registros guardados
	 * @throws SQLException Si ocurre un error de base de datos al guardar
	 */
	public int guardar() throws SQLException {
		switch (getTipoOperacion()) {
			case CREAR:
				return crear();
			case ACTUALIZAR:
				return actualizar();
		}
		return -1;
	}

	/**
	 * Elimina registros de TipoLugar.
	 * @return Un int con el n�mero de registros eliminados
	 * @throws SQLException Si ocurre un error de base de datos al eliminar
	 */
	public int eliminar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		return sentencia.getRegistrosAfectados();
	}

	/**
	 * Consulta los datos de TipoLugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	public IDDataSet consultar() throws SQLException {
		switch (getTipoOperacion()) {
			case CONSULTAR_POR_PK:
				return consultarPorPK();
			case CONSULTA_GENERICA:
				return consultaGenerica();
		}
		return null;
	}

	/**
	 * Crea un registro de TipoLugar.
	 * @return Un int con el n�mero de registros creados
	 * @throws SQLException Si ocurre un error de base de datos al crear
	 */
	private int crear() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha creado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� crear m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de TipoLugar.
	 * @return Un int con el n�mero de registros actualizados
	 * @throws SQLException Si ocurre un error de base de datos al actualizar
	 */
	private int actualizar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha actualizado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� actualizar m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de TipoLugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorPK() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarTipoLugar(resultado);
		return resultado;
	}

	/**
	 * Consulta gen�rica de los datos de TipoLugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultaGenerica() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresGenericos(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosTipoLugar(resultado);
		return resultado;
	}

	/**
	 * Asigna los valores para pk en una sentencia SQL.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresPK(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setInt("IDE_TIPO_LUGAR", pkTipoLugar.getIdeTipoLugar());
	}

	/**
	 * Asigna todos los valores de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresObjeto(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setString("NOM_TIPO_LUGAR", attTipoLugar.getNomTipoLugar());
		unaSentencia.setLong("IDE_USUARIO_CAMBIO", attTipoLugar.getIdeUsuarioCambio());
		unaSentencia.setTimestamp("FEC_CAMBIO", attTipoLugar.getFecCambio());
	}

	/**
	 * Construye un objeto TipoLugar con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private void cargarTipoLugar(IDDataSet resultado) throws SQLException {
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		toTipoLugar = completarTipoLugar(resultado);
	}

	/**
	 * Construye objetos TipoLugar con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar los objetos
	 */
	private void cargarObjetosTipoLugar(IDDataSet resultado) throws SQLException {
		objetosTipoLugar = new ArrayList<DTipoLugarTO>();
		toTipoLugar = null;
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		do {
			DTipoLugarTO objeto = completarTipoLugar(resultado);
			objetosTipoLugar.add(objeto);
		} while (resultado.siguiente());
		resultado.primero();
	}

	/**
	 * Construye un objeto TipoLugar con base en el data set.
	 * El data set debe contener datos en la posici�n actual.
	 * @param resultado Contenedor de los datos
	 * @return Un TipoLugar
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private DTipoLugarTO completarTipoLugar(IDDataSet resultado) throws SQLException {
		// Conformar el objeto PK
		DTipoLugarPKTO pk = new DTipoLugarPKTO();
		//java.lang.Integer
		pk.setIdeTipoLugar(resultado.getIntWrapper("IDE_TIPO_LUGAR"));

		// Conformar el objeto Att
		DTipoLugarAttTO att = new DTipoLugarAttTO();
		//java.lang.String
		att.setNomTipoLugar(resultado.getString("NOM_TIPO_LUGAR"));
		//java.lang.Long
		att.setIdeUsuarioCambio(resultado.getLongWrapper("IDE_USUARIO_CAMBIO"));
		//java.sql.Timestamp
		att.setFecCambio((Timestamp)resultado.getValorPorNombre("FEC_CAMBIO"));

		// Conformar el TO
		DTipoLugarTO to = new DTipoLugarTO();
		to.setPK(pk);
		to.setAtt(att);
		return to;
	}

	/**
	 * Devuelve el objeto TipoLugar que se haya consultado.
	 * @return Un objeto DTipoLugarTO
	 */
	public DTipoLugarTO getTipoLugar() {
		return toTipoLugar;
	}

	/**
	 * Devuelve la colecci�n de objetos TipoLugar que se hayan consultado.
	 * @return Un Collection con objetos DTipoLugarTO
	 */
	public Collection<DTipoLugarTO> getColeccionTipoLugar() {
		return objetosTipoLugar;
	}

	/**
	 * Indica si el DAO es de ejecuci�n libre.
	 * @return true si es de ejecuci�n libre; false de lo contrario
	 */
	public boolean isEjecucionLibre() {
		return false;
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado por el administrador de persistencia.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 * @todo COMPLEMENTAR
	 */
	public boolean validar() throws DValidarExcepcion {
		DManipuladorMensaje manipulador;
		String operacion = null;
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (getTipoOperacion()) {
			case CREAR: operacion = "la creaci�n"; break;
			case ACTUALIZAR: operacion = "la actualizaci�n"; break;
			case ELIMINAR: operacion = "la eliminaci�n"; break;
			case CONSULTAR_POR_PK: operacion = "la consulta"; break;
			case CONSULTA_GENERICA: operacion = "la consulta"; break;
		}

		if (operacion == null) {
			manipulador = new DManipuladorMensaje(IDArqMensajes.ME_OPER_INVALIDA);
			String mensaje = manipulador.getMensaje();
			throw new DValidarExcepcion(mensaje, mensaje);
		}

		if (tipoOperacion == CREAR || tipoOperacion == ACTUALIZAR) {
			parametros.put(this.getClass().getName()+":validar:toTipoLugar",toTipoLugar);
			parametros.put(this.getClass().getName()+":validar:pkTipoLugar",pkTipoLugar);
			parametros.put(this.getClass().getName()+":validar:attTipoLugar",attTipoLugar);

			parametros.put(this.getClass().getName()+":validar:pkTipoLugar.getIdeTipoLugar()",pkTipoLugar.getIdeTipoLugar());
			parametros.put(this.getClass().getName()+":validar:attTipoLugar.getNomTipoLugar()",attTipoLugar.getNomTipoLugar());
			parametros.put(this.getClass().getName()+":validar:attTipoLugar.getIdeUsuarioCambio()",attTipoLugar.getIdeUsuarioCambio());
			parametros.put(this.getClass().getName()+":validar:attTipoLugar.getFecCambio()",attTipoLugar.getFecCambio());
		}

		if (tipoOperacion == CONSULTAR_POR_PK || tipoOperacion == ELIMINAR) {
			parametros.put(this.getClass().getName()+":validar:pkTipoLugar",pkTipoLugar);
			parametros.put(this.getClass().getName()+":validar:pkTipoLugar.getIdeTipoLugar()",pkTipoLugar.getIdeTipoLugar());
		}

		if (tipoOperacion == CONSULTA_GENERICA) {
			parametros.put(this.getClass().getName()+":validar:toTipoLugar",toTipoLugar);
		}


		validarParametros(operacion,parametros);
		return true;
	}
}
