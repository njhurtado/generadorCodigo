/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;


import co.gov.dian.muisca.arquitectura.automatizacion.dao.IDDAODireccion;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.IDDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.impl.DDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para crear un objeto Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvCrearDireccionImpl extends DCmdSrvCrearDireccion {

	private static final long serialVersionUID = -755680455L; 

	/**
	 * Ejecuta el comando de servicio.
	 *
	 * @throws DExcepcion Si ocurre algn error al realizar la
	 * creaci�n de Direccion
	 */
	protected void ejecutarComando() throws DExcepcion {
		IDAdminPersistencia admin = getAdministradorPersistencia();
		try {
			// Iniciar los DAO's
			IDDAOFactoryArquitectura fabrica = new DDAOFactoryArquitectura();
			IDDAODireccion dao = fabrica.getDaoDireccion();

			// Crear
			dao.inicializarCrear(toDireccion);
			admin.guardar(dao);
		}
		finally {
			admin.cerrarSesion();
		}
	}
}
