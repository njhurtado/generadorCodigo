/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para la PK de Lugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DLugarPKTO implements IDTO {

	private static final long serialVersionUID = -615109098L; 

  // Campos de la PK
	private java.lang.Integer ideLugar;

	/**
	 * Construye un nuevo DLugarPKTO por defecto.
	 */
	public DLugarPKTO() { }

	/**
	 * Construye un nuevo DLugarPKTO con los elementos de la llave primaria.
	 * @param ideLugar java.lang.Integer
	 */
	public DLugarPKTO(java.lang.Integer ideLugar) {
		setIdeLugar(ideLugar);
	}

	/**
	 * Devuelve el valor de ideLugar.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeLugar() {
		return ideLugar;
	}

	/**
	 * Establece el valor de ideLugar.
	 * @param ideLugar El nuevo valor de ideLugar
	 */
	public void setIdeLugar(java.lang.Integer ideLugar) {
		this.ideLugar = ideLugar;
	}

	/**
	 * Compara el objeto actual con el objeto especificado.
	 * @param objeto Objeto con el cual se compara
	 * @return true si los objetos son iguales; false de lo contrario
	 */
	public boolean equals(Object objeto) {
		if (this == objeto) {
			return true;
		}
		if (!(objeto instanceof DLugarPKTO)) {
			return false;
		}
		DLugarPKTO otro = (DLugarPKTO) objeto;
		EqualsBuilder builder = new EqualsBuilder();
		builder.append(getIdeLugar(),  otro.getIdeLugar());
		return builder.isEquals();
	}

	/**
	 * Devuelve el hash code del objeto.
	 * @return int
	 */
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();
		builder.append(getIdeLugar());
		return builder.toHashCode();
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("ideLugar", getIdeLugar());
		return builder.toString();
	}
}
