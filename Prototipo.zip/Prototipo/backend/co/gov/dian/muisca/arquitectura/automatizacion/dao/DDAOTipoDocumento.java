/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.sql.*;
import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.general.persistencia.dao.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.dataset.*;
import co.gov.dian.muisca.arquitectura.mensajes.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para TipoDocumento.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDAOTipoDocumento extends DDAO implements IDDAOTipoDocumento {
	/** colecci�n de objetos DTipoDocumentoTO */
	private Collection<DTipoDocumentoTO> objetosTipoDocumento;
	/** Objeto de transporte de TipoDocumento */
	private DTipoDocumentoTO toTipoDocumento;
	/** Llave primaria de TipoDocumento */
	private DTipoDocumentoPKTO pkTipoDocumento;
	/** Atributos de TipoDocumento */
	private DTipoDocumentoAttTO attTipoDocumento;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	public void inicializarConsultarPorPK(DTipoDocumentoPKTO pkTipoDocumento) {
		setTipoOperacion(CONSULTAR_POR_PK);
		this.pkTipoDocumento = pkTipoDocumento;
	}

	/**
	 * Inicializa la creaci�nn de TipoDocumento.
	 * @param toTipoDocumento Objeto de Transporte de TipoDocumento
	 */
	public void inicializarCrear(DTipoDocumentoTO toTipoDocumento) {
		setTipoOperacion(CREAR);
		this.toTipoDocumento = toTipoDocumento;
		if (toTipoDocumento != null) {
			pkTipoDocumento = this.toTipoDocumento.getPK();
			attTipoDocumento = this.toTipoDocumento.getAtt();
		}
	}

	/**
	 * Inicializa la actualizaci�n de TipoDocumento.
	 * @param toTipoDocumento Objeto de Transporte de TipoDocumento
	 */
	public void inicializarActualizar(DTipoDocumentoTO toTipoDocumento) {
		setTipoOperacion(ACTUALIZAR);
		this.toTipoDocumento = toTipoDocumento;
		if (toTipoDocumento != null) {
			pkTipoDocumento = this.toTipoDocumento.getPK();
			attTipoDocumento = this.toTipoDocumento.getAtt();
		}
	}

	/**
	 * Inicializa la eliminaci�n de TipoDocumento.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	public void inicializarEliminar(DTipoDocumentoPKTO pkTipoDocumento) {
		setTipoOperacion(ELIMINAR);
		this.pkTipoDocumento = pkTipoDocumento;
	}

	/**
	 * Inicializa la consulta gen�rica de TipoDocumento.
	 * @param attTipoDocumento Atributos de TipoDocumento
	 */
	public void inicializarConsultaGenerica(DTipoDocumentoTO toTipoDocumento) {
		setTipoOperacion(CONSULTA_GENERICA);

		this.toTipoDocumento = toTipoDocumento;
		if (toTipoDocumento != null) {
			pkTipoDocumento = this.toTipoDocumento.getPK();
			attTipoDocumento = this.toTipoDocumento.getAtt();
		}
	}

	/**
	 * Devuelve las sentencias sql a ejecutar, dependiendo del tipo de operaci�n a realizar.
	 * @return Un Map de Strings con la relaci�n de sentencias sql
	 */
	public Map<String, String> getSentenciasSQL() {
		Map<String, String> m = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();
		switch (getTipoOperacion()) {
			case CREAR:
				sql.append("insert into TIPO_DOCUMENTO")
					.append(" (IDE_TIPO_DOCUMENTO, NOM_TIPO_DOCUMENTO, IDE_USUARIO_CAMBIO, FEC_CAMBIO)")
					.append(" VALUES (:IDE_TIPO_DOCUMENTO, :NOM_TIPO_DOCUMENTO, :IDE_USUARIO_CAMBIO, :FEC_CAMBIO)");
				m.put("sentencia1", sql.toString());
				break;
			case ACTUALIZAR:
				sql.append("update TIPO_DOCUMENTO")
					.append(" set NOM_TIPO_DOCUMENTO=:NOM_TIPO_DOCUMENTO, IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO, FEC_CAMBIO=:FEC_CAMBIO")
					.append(" where IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO");
				m.put("sentencia1", sql.toString());
				break;
			case ELIMINAR:
				sql.append("delete from TIPO_DOCUMENTO")
					.append(" where IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_PK:
				sql.append("select * from TIPO_DOCUMENTO")
					.append(" where IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTA_GENERICA:
				sql.append("select * from TIPO_DOCUMENTO where ")
					.append(generarFiltroGenerico());
				m.put("sentencia1", sql.toString());
				break;
		}
		return m;
	}


	/**
	 * obtenerConsultaGenerica
	 *
	 * @return StringBuffer
	 */
	private String generarFiltroGenerico() {
		StringBuffer condiciones = new StringBuffer();
		String y = " AND ";
		boolean append = false;

		if (pkTipoDocumento != null) {

			if (pkTipoDocumento.getIdeTipoDocumento() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO");
				append = true;

			}
		}

		if (attTipoDocumento != null) {

			if (attTipoDocumento.getNomTipoDocumento() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_TIPO_DOCUMENTO=:NOM_TIPO_DOCUMENTO");
				append = true;

			}
			if (attTipoDocumento.getIdeUsuarioCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO");
				append = true;

			}
			if (attTipoDocumento.getFecCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("FEC_CAMBIO=:FEC_CAMBIO");
				append = true;

			}
		}

		return condiciones.toString();
	}

	/**
	 * Asigna los valores no nulos de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresGenericos(DSentenciaSQL unaSentencia) throws SQLException {
		if (pkTipoDocumento != null) {
			if (pkTipoDocumento.getIdeTipoDocumento() != null) {
				unaSentencia.setInt("IDE_TIPO_DOCUMENTO", pkTipoDocumento.getIdeTipoDocumento());
			}
		}

		if (attTipoDocumento != null) {
			if (attTipoDocumento.getNomTipoDocumento() != null) {
				unaSentencia.setString("NOM_TIPO_DOCUMENTO", attTipoDocumento.getNomTipoDocumento());
			}
			if (attTipoDocumento.getIdeUsuarioCambio() != null) {
				unaSentencia.setLong("IDE_USUARIO_CAMBIO", attTipoDocumento.getIdeUsuarioCambio());
			}
			if (attTipoDocumento.getFecCambio() != null) {
				unaSentencia.setTimestamp("FEC_CAMBIO", attTipoDocumento.getFecCambio());
			}
		}
	}

	/**
	 * Guarda los datos de TipoDocumento.
	 * @return @return Un int con el n�mero de registros guardados
	 * @throws SQLException Si ocurre un error de base de datos al guardar
	 */
	public int guardar() throws SQLException {
		switch (getTipoOperacion()) {
			case CREAR:
				return crear();
			case ACTUALIZAR:
				return actualizar();
		}
		return -1;
	}

	/**
	 * Elimina registros de TipoDocumento.
	 * @return Un int con el n�mero de registros eliminados
	 * @throws SQLException Si ocurre un error de base de datos al eliminar
	 */
	public int eliminar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		return sentencia.getRegistrosAfectados();
	}

	/**
	 * Consulta los datos de TipoDocumento.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	public IDDataSet consultar() throws SQLException {
		switch (getTipoOperacion()) {
			case CONSULTAR_POR_PK:
				return consultarPorPK();
			case CONSULTA_GENERICA:
				return consultaGenerica();
		}
		return null;
	}

	/**
	 * Crea un registro de TipoDocumento.
	 * @return Un int con el n�mero de registros creados
	 * @throws SQLException Si ocurre un error de base de datos al crear
	 */
	private int crear() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha creado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� crear m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de TipoDocumento.
	 * @return Un int con el n�mero de registros actualizados
	 * @throws SQLException Si ocurre un error de base de datos al actualizar
	 */
	private int actualizar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha actualizado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� actualizar m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de TipoDocumento.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorPK() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarTipoDocumento(resultado);
		return resultado;
	}

	/**
	 * Consulta gen�rica de los datos de TipoDocumento.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultaGenerica() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresGenericos(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosTipoDocumento(resultado);
		return resultado;
	}

	/**
	 * Asigna los valores para pk en una sentencia SQL.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresPK(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setInt("IDE_TIPO_DOCUMENTO", pkTipoDocumento.getIdeTipoDocumento());
	}

	/**
	 * Asigna todos los valores de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresObjeto(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setString("NOM_TIPO_DOCUMENTO", attTipoDocumento.getNomTipoDocumento());
		unaSentencia.setLong("IDE_USUARIO_CAMBIO", attTipoDocumento.getIdeUsuarioCambio());
		unaSentencia.setTimestamp("FEC_CAMBIO", attTipoDocumento.getFecCambio());
	}

	/**
	 * Construye un objeto TipoDocumento con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private void cargarTipoDocumento(IDDataSet resultado) throws SQLException {
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		toTipoDocumento = completarTipoDocumento(resultado);
	}

	/**
	 * Construye objetos TipoDocumento con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar los objetos
	 */
	private void cargarObjetosTipoDocumento(IDDataSet resultado) throws SQLException {
		objetosTipoDocumento = new ArrayList<DTipoDocumentoTO>();
		toTipoDocumento = null;
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		do {
			DTipoDocumentoTO objeto = completarTipoDocumento(resultado);
			objetosTipoDocumento.add(objeto);
		} while (resultado.siguiente());
		resultado.primero();
	}

	/**
	 * Construye un objeto TipoDocumento con base en el data set.
	 * El data set debe contener datos en la posici�n actual.
	 * @param resultado Contenedor de los datos
	 * @return Un TipoDocumento
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private DTipoDocumentoTO completarTipoDocumento(IDDataSet resultado) throws SQLException {
		// Conformar el objeto PK
		DTipoDocumentoPKTO pk = new DTipoDocumentoPKTO();
		//java.lang.Integer
		pk.setIdeTipoDocumento(resultado.getIntWrapper("IDE_TIPO_DOCUMENTO"));

		// Conformar el objeto Att
		DTipoDocumentoAttTO att = new DTipoDocumentoAttTO();
		//java.lang.String
		att.setNomTipoDocumento(resultado.getString("NOM_TIPO_DOCUMENTO"));
		//java.lang.Long
		att.setIdeUsuarioCambio(resultado.getLongWrapper("IDE_USUARIO_CAMBIO"));
		//java.sql.Timestamp
		att.setFecCambio((Timestamp)resultado.getValorPorNombre("FEC_CAMBIO"));

		// Conformar el TO
		DTipoDocumentoTO to = new DTipoDocumentoTO();
		to.setPK(pk);
		to.setAtt(att);
		return to;
	}

	/**
	 * Devuelve el objeto TipoDocumento que se haya consultado.
	 * @return Un objeto DTipoDocumentoTO
	 */
	public DTipoDocumentoTO getTipoDocumento() {
		return toTipoDocumento;
	}

	/**
	 * Devuelve la colecci�n de objetos TipoDocumento que se hayan consultado.
	 * @return Un Collection con objetos DTipoDocumentoTO
	 */
	public Collection<DTipoDocumentoTO> getColeccionTipoDocumento() {
		return objetosTipoDocumento;
	}

	/**
	 * Indica si el DAO es de ejecuci�n libre.
	 * @return true si es de ejecuci�n libre; false de lo contrario
	 */
	public boolean isEjecucionLibre() {
		return false;
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado por el administrador de persistencia.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 * @todo COMPLEMENTAR
	 */
	public boolean validar() throws DValidarExcepcion {
		DManipuladorMensaje manipulador;
		String operacion = null;
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (getTipoOperacion()) {
			case CREAR: operacion = "la creaci�n"; break;
			case ACTUALIZAR: operacion = "la actualizaci�n"; break;
			case ELIMINAR: operacion = "la eliminaci�n"; break;
			case CONSULTAR_POR_PK: operacion = "la consulta"; break;
			case CONSULTA_GENERICA: operacion = "la consulta"; break;
		}

		if (operacion == null) {
			manipulador = new DManipuladorMensaje(IDArqMensajes.ME_OPER_INVALIDA);
			String mensaje = manipulador.getMensaje();
			throw new DValidarExcepcion(mensaje, mensaje);
		}

		if (tipoOperacion == CREAR || tipoOperacion == ACTUALIZAR) {
			parametros.put(this.getClass().getName()+":validar:toTipoDocumento",toTipoDocumento);
			parametros.put(this.getClass().getName()+":validar:pkTipoDocumento",pkTipoDocumento);
			parametros.put(this.getClass().getName()+":validar:attTipoDocumento",attTipoDocumento);

			parametros.put(this.getClass().getName()+":validar:pkTipoDocumento.getIdeTipoDocumento()",pkTipoDocumento.getIdeTipoDocumento());
			parametros.put(this.getClass().getName()+":validar:attTipoDocumento.getNomTipoDocumento()",attTipoDocumento.getNomTipoDocumento());
			parametros.put(this.getClass().getName()+":validar:attTipoDocumento.getIdeUsuarioCambio()",attTipoDocumento.getIdeUsuarioCambio());
			parametros.put(this.getClass().getName()+":validar:attTipoDocumento.getFecCambio()",attTipoDocumento.getFecCambio());
		}

		if (tipoOperacion == CONSULTAR_POR_PK || tipoOperacion == ELIMINAR) {
			parametros.put(this.getClass().getName()+":validar:pkTipoDocumento",pkTipoDocumento);
			parametros.put(this.getClass().getName()+":validar:pkTipoDocumento.getIdeTipoDocumento()",pkTipoDocumento.getIdeTipoDocumento());
		}

		if (tipoOperacion == CONSULTA_GENERICA) {
			parametros.put(this.getClass().getName()+":validar:toTipoDocumento",toTipoDocumento);
		}


		validarParametros(operacion,parametros);
		return true;
	}
}
