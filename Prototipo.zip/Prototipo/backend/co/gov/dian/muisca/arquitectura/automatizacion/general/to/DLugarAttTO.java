/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para los atributos de Lugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DLugarAttTO implements IDTO {
	private static final long serialVersionUID = 1446821373L; 

	// Atributos
	private java.lang.Integer ideTipoLugar;
	private java.lang.Integer ideLugarPadre;
	private java.lang.String nomTipoLugar;
	private java.lang.Long ideUsuarioCambio;
	private java.sql.Timestamp fecCambio;

	/**
	 * Construye un nuevo DLugarAttTO por defecto.
	 */
	public DLugarAttTO() { }

	/**
	 * Construye un nuevo DLugarAttTO con los atributos.
	 * @param ideTipoLugar java.lang.Integer
	 * @param ideLugarPadre java.lang.Integer
	 * @param nomTipoLugar java.lang.String
	 * @param ideUsuarioCambio java.lang.Long
	 * @param fecCambio java.sql.Timestamp
	 */
	public DLugarAttTO(java.lang.Integer ideTipoLugar, java.lang.Integer ideLugarPadre, java.lang.String nomTipoLugar, java.lang.Long ideUsuarioCambio, java.sql.Timestamp fecCambio) {
		setIdeTipoLugar(ideTipoLugar);
		setIdeLugarPadre(ideLugarPadre);
		setNomTipoLugar(nomTipoLugar);
		setIdeUsuarioCambio(ideUsuarioCambio);
		setFecCambio(fecCambio);
	}

	/**
	 * Devuelve el valor de ideTipoLugar.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeTipoLugar() {
		return ideTipoLugar;
	}

	/**
	 * Establece el valor de ideTipoLugar.
	 * @param ideTipoLugar El nuevo valor de ideTipoLugar
	 */
	public void setIdeTipoLugar(java.lang.Integer ideTipoLugar) {
		this.ideTipoLugar = ideTipoLugar;
	}

	/**
	 * Devuelve el valor de ideLugarPadre.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeLugarPadre() {
		return ideLugarPadre;
	}

	/**
	 * Establece el valor de ideLugarPadre.
	 * @param ideLugarPadre El nuevo valor de ideLugarPadre
	 */
	public void setIdeLugarPadre(java.lang.Integer ideLugarPadre) {
		this.ideLugarPadre = ideLugarPadre;
	}

	/**
	 * Devuelve el valor de nomTipoLugar.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomTipoLugar() {
		return nomTipoLugar;
	}

	/**
	 * Establece el valor de nomTipoLugar.
	 * @param nomTipoLugar El nuevo valor de nomTipoLugar
	 */
	public void setNomTipoLugar(java.lang.String nomTipoLugar) {
		this.nomTipoLugar = nomTipoLugar;
	}

	/**
	 * Devuelve el valor de ideUsuarioCambio.
	 * @return Un objeto java.lang.Long
	 */
	public java.lang.Long getIdeUsuarioCambio() {
		return ideUsuarioCambio;
	}

	/**
	 * Establece el valor de ideUsuarioCambio.
	 * @param ideUsuarioCambio El nuevo valor de ideUsuarioCambio
	 */
	public void setIdeUsuarioCambio(java.lang.Long ideUsuarioCambio) {
		this.ideUsuarioCambio = ideUsuarioCambio;
	}

	/**
	 * Devuelve el valor de fecCambio.
	 * @return Un objeto java.sql.Timestamp
	 */
	public java.sql.Timestamp getFecCambio() {
		return fecCambio;
	}

	/**
	 * Establece el valor de fecCambio.
	 * @param fecCambio El nuevo valor de fecCambio
	 */
	public void setFecCambio(java.sql.Timestamp fecCambio) {
		this.fecCambio = fecCambio;
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("ideTipoLugar", getIdeTipoLugar());
		builder.append("ideLugarPadre", getIdeLugarPadre());
		builder.append("nomTipoLugar", getNomTipoLugar());
		builder.append("ideUsuarioCambio", getIdeUsuarioCambio());
		builder.append("fecCambio", getFecCambio());
		return builder.toString();
	}
}
