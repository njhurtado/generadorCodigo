/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import co.gov.dian.muisca.arquitectura.automatizacion.servicios.DCmdSrvConsLstDireccion;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;
import co.gov.dian.muisca.arquitectura.acciones.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar objetos Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsLstDireccionImpl extends DCmdAccConsLstDireccion {
	private static final long serialVersionUID = 2121998718L; 

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		try {
			DCmdSrvConsLstDireccion servicio = (DCmdSrvConsLstDireccion) getServicio("arquitectura.automatizacion.DCmdSrvConsLstDireccion");
			servicio.setPaginable(true);
			switch (tipoOperacion) {
			case CONSULTAR_POR_LUGAR:
				servicio.inicializarConsultarPorLugar(pkLugar);
				break;
			case CONSULTAR_POR_LUGAR:
				servicio.inicializarConsultarPorLugar(pkLugar);
				break;

			case CONSULTA_GENERICA:
				servicio.inicializarConsultaGenerica(toDireccion);
				break;


			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos Direccion"), getMensajeOperInvalida());
			}
			servicio.ejecutar();
			objetosDireccion = servicio.getColeccionDireccion();
			isOk = true;
		}
		catch (DExcepcion ex) {
			mensajeError = ex.getMessage();
			mensajeErrorDetallado = ex.getMensajeDetallado();
			isOk = false;
		}
	}
}
