/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarPKTO;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public interface IDDAODireccion extends IDDAO {
	static final int CONSULTAR_POR_PK = 0;
	static final int CONSULTAR_POR_LUGAR = 1;
	static final int CONSULTAR_POR_LUGAR = 2;
	static final int CREAR = 3;
	static final int ACTUALIZAR = 4;
	static final int ELIMINAR = 5;
	static final int CONSULTA_GENERICA = 6;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkDireccion Llave primaria de Direccion
	 */
	void inicializarConsultarPorPK(DDireccionPKTO pkDireccion);

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	void inicializarConsultarPorLugar(DLugarPKTO pkLugar);

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	void inicializarConsultarPorLugar(DLugarPKTO pkLugar);

	/**
	 * Inicializa la creaci�n de Direccion.
	 * @param toDireccion Objeto de Transporte de Direccion
	 */
	void inicializarCrear(DDireccionTO toDireccion);

	/**
	 * Inicializa la actualizaci�n de Direccion.
	 * @param toDireccion Objeto de Transporte de Direccion
	 */
	void inicializarActualizar(DDireccionTO toDireccion);

	/**
	 * Inicializa la eliminaci�n de Direccion.
	 * @param pkDireccion Llave primaria de Direccion
	 */
	void inicializarEliminar(DDireccionPKTO pkDireccion);

	/**
	 * Inicializa la eliminaci�n de Direccion.
	 * @param attDireccion Atributos de Direccion
	 */
	void inicializarConsultaGenerica(DDireccionTO toDireccion);

	/**
	 * Devuelve el objeto Direccion que se haya consultado.
	 * @return Un objeto DDireccionTO
	 */
	DDireccionTO getDireccion();

	/**
	 * Devuelve la colecci�n de objetos Direccion que se hayan consultado.
	 * @return Un Collection con objetos DDireccionTO
	 */
	Collection<DDireccionTO> getColeccionDireccion();
}
