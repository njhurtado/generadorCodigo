/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyentePKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoPKTO;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public interface IDDAOContribuyente extends IDDAO {
	static final int CONSULTAR_POR_PK = 0;
	static final int CONSULTAR_POR_TIPODOCUMENTO = 1;
	static final int CREAR = 2;
	static final int ACTUALIZAR = 3;
	static final int ELIMINAR = 4;
	static final int CONSULTA_GENERICA = 5;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	void inicializarConsultarPorPK(DContribuyentePKTO pkContribuyente);

	/**
	 * Inicializa la consulta por TipoDocumento.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	void inicializarConsultarPorTipoDocumento(DTipoDocumentoPKTO pkTipoDocumento);

	/**
	 * Inicializa la creaci�n de Contribuyente.
	 * @param toContribuyente Objeto de Transporte de Contribuyente
	 */
	void inicializarCrear(DContribuyenteTO toContribuyente);

	/**
	 * Inicializa la actualizaci�n de Contribuyente.
	 * @param toContribuyente Objeto de Transporte de Contribuyente
	 */
	void inicializarActualizar(DContribuyenteTO toContribuyente);

	/**
	 * Inicializa la eliminaci�n de Contribuyente.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	void inicializarEliminar(DContribuyentePKTO pkContribuyente);

	/**
	 * Inicializa la eliminaci�n de Contribuyente.
	 * @param attContribuyente Atributos de Contribuyente
	 */
	void inicializarConsultaGenerica(DContribuyenteTO toContribuyente);

	/**
	 * Devuelve el objeto Contribuyente que se haya consultado.
	 * @return Un objeto DContribuyenteTO
	 */
	DContribuyenteTO getContribuyente();

	/**
	 * Devuelve la colecci�n de objetos Contribuyente que se hayan consultado.
	 * @return Un Collection con objetos DContribuyenteTO
	 */
	Collection<DContribuyenteTO> getColeccionContribuyente();
}
