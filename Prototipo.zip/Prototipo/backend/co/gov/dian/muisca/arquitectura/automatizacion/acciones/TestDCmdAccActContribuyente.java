/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import test.*;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para actualizar un objeto Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class TestDCmdAccActContribuyente extends TestCaseBase {

	private DCmdAccActContribuyente dDCmdAccActContribuyente = null;

	protected void setUp() throws Exception {
		super.setUp();
		dDCmdAccActContribuyente = (DCmdAccActContribuyente)
		getAccion("arquitectura.automatizacion.DCmdAccActContribuyente");
	}

	protected void tearDown() throws Exception {
		dDCmdAccActContribuyente = null;
		super.tearDown();
	}

	public void testEjecutar() throws DExcepcion {

		dDCmdAccActContribuyente.ejecutar();

	}  
}

