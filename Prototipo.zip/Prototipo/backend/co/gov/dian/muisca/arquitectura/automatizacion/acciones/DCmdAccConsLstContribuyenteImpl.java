/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import co.gov.dian.muisca.arquitectura.automatizacion.servicios.DCmdSrvConsLstContribuyente;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;
import co.gov.dian.muisca.arquitectura.acciones.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar objetos Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsLstContribuyenteImpl extends DCmdAccConsLstContribuyente {
	private static final long serialVersionUID = -1789297499L; 

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		try {
			DCmdSrvConsLstContribuyente servicio = (DCmdSrvConsLstContribuyente) getServicio("arquitectura.automatizacion.DCmdSrvConsLstContribuyente");
			servicio.setPaginable(true);
			switch (tipoOperacion) {
			case CONSULTAR_POR_TIPODOCUMENTO:
				servicio.inicializarConsultarPorTipoDocumento(pkTipoDocumento);
				break;

			case CONSULTA_GENERICA:
				servicio.inicializarConsultaGenerica(toContribuyente);
				break;


			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos Contribuyente"), getMensajeOperInvalida());
			}
			servicio.ejecutar();
			objetosContribuyente = servicio.getColeccionContribuyente();
			isOk = true;
		}
		catch (DExcepcion ex) {
			mensajeError = ex.getMessage();
			mensajeErrorDetallado = ex.getMensajeDetallado();
			isOk = false;
		}
	}
}
