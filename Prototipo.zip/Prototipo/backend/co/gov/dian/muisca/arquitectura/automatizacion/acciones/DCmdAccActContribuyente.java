/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyentePKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para actualizar un objeto Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccActContribuyente extends DComandoAccion {
	private static final long serialVersionUID = -1382389680L; 

	/** Objeto de transporte de Contribuyente */
	protected DContribuyenteTO toContribuyente;
	/** Llave primaria de Contribuyente */
	protected DContribuyentePKTO pkContribuyente;
	/** Atributos de Contribuyente */
	protected DContribuyenteAttTO attContribuyente;

	/**
	 * Inicializa la actualizaci�n de Contribuyente.
	 * @param toContribuyente Objeto de Transporte de Contribuyente
	 */
	public void inicializar(DContribuyenteTO toContribuyente) {
		isOk = false;
		this.toContribuyente = toContribuyente;
		if (toContribuyente != null) {
			pkContribuyente = this.toContribuyente.getPK();
			attContribuyente = this.toContribuyente.getAtt();
		}
	}

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdAccActContribuyente();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite actualizar un objeto Contribuyente";
	}

	/**
	 * M�odo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		parametros.put(this.getClass().getName()+":validar:toContribuyente",toContribuyente);
		parametros.put(this.getClass().getName()+":validar:pkContribuyente",pkContribuyente);
		parametros.put(this.getClass().getName()+":validar:attContribuyente",attContribuyente);
		parametros.put(this.getClass().getName()+":validar:pkContribuyente.getIdeContribuyente()",pkContribuyente.getIdeContribuyente());
		parametros.put(this.getClass().getName()+":validar:attContribuyente.getIdeTipoDocumento()",attContribuyente.getIdeTipoDocumento());
		parametros.put(this.getClass().getName()+":validar:attContribuyente.getIdeUsuarioCambio()",attContribuyente.getIdeUsuarioCambio());
		parametros.put(this.getClass().getName()+":validar:attContribuyente.getFecCambio()",attContribuyente.getFecCambio());
		validarParametros("Actualizar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdAccActContribuyente) {
			DCmdAccActContribuyente copia = (DCmdAccActContribuyente) comando;
			copia.toContribuyente = toContribuyente;
			copia.pkContribuyente = pkContribuyente;
			copia.attContribuyente = attContribuyente;
		}
	}
}
