/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;


import co.gov.dian.muisca.arquitectura.automatizacion.dao.IDDAODireccion;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.IDDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.impl.DDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para consultar objetos Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvConsLstDireccionImpl extends DCmdSrvConsLstDireccion {

	private static final long serialVersionUID = 1536140420L; 

	/**
	 * Ejecuta el comando de servicio.
	 *
	 * @throws DExcepcion Si ocurre algn error al realizar la
	 * consulta de objetos Direccion
	 */
	protected void ejecutarComando() throws DExcepcion {
		IDAdminPersistencia admin = getAdministradorPersistencia();
		try {
			// Iniciar los DAO's
			IDDAOFactoryArquitectura fabrica = new DDAOFactoryArquitectura();
			IDDAODireccion dao = fabrica.getDaoDireccion();

			switch (tipoOperacion) {
				case CONSULTAR_POR_LUGAR:
					dao.inicializarConsultarPorLugar(pkLugar);
					break;
				case CONSULTAR_POR_LUGAR:
					dao.inicializarConsultarPorLugar(pkLugar);
					break;

				case CONSULTA_GENERICA:
					dao.inicializarConsultaGenerica(toDireccion);
					break;

				default:
					throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos Direccion"), getMensajeOperInvalida());
			}

			// Consultar
			admin.buscar(dao);
			objetosDireccion = dao.getColeccionDireccion();
		}
		finally {
			admin.cerrarSesion();
		}
	}
}
