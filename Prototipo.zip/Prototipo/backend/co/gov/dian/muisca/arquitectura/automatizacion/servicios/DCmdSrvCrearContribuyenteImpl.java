/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;


import co.gov.dian.muisca.arquitectura.automatizacion.dao.IDDAOContribuyente;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.IDDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.impl.DDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para crear un objeto Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvCrearContribuyenteImpl extends DCmdSrvCrearContribuyente {

	private static final long serialVersionUID = -2023079712L; 

	/**
	 * Ejecuta el comando de servicio.
	 *
	 * @throws DExcepcion Si ocurre algn error al realizar la
	 * creaci�n de Contribuyente
	 */
	protected void ejecutarComando() throws DExcepcion {
		IDAdminPersistencia admin = getAdministradorPersistencia();
		try {
			// Iniciar los DAO's
			IDDAOFactoryArquitectura fabrica = new DDAOFactoryArquitectura();
			IDDAOContribuyente dao = fabrica.getDaoContribuyente();

			// Crear
			dao.inicializarCrear(toContribuyente);
			admin.guardar(dao);
		}
		finally {
			admin.cerrarSesion();
		}
	}
}
