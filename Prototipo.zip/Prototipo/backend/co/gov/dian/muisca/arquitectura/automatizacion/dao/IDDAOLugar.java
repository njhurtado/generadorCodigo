/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarPKTO;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para Lugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public interface IDDAOLugar extends IDDAO {
	static final int CONSULTAR_POR_PK = 0;
	static final int CONSULTAR_POR_TIPOLUGAR = 1;
	static final int CONSULTAR_POR_LUGAR = 2;
	static final int CONSULTAR_POR_LUGAR = 3;
	static final int CREAR = 4;
	static final int ACTUALIZAR = 5;
	static final int ELIMINAR = 6;
	static final int CONSULTA_GENERICA = 7;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkLugar Llave primaria de Lugar
	 */
	void inicializarConsultarPorPK(DLugarPKTO pkLugar);

	/**
	 * Inicializa la consulta por TipoLugar.
	 * @param pkTipoLugar Llave primaria de TipoLugar
	 */
	void inicializarConsultarPorTipoLugar(DTipoLugarPKTO pkTipoLugar);

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	void inicializarConsultarPorLugar(DLugarPKTO pkLugar);

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	void inicializarConsultarPorLugar(DLugarPKTO pkLugar);

	/**
	 * Inicializa la creaci�n de Lugar.
	 * @param toLugar Objeto de Transporte de Lugar
	 */
	void inicializarCrear(DLugarTO toLugar);

	/**
	 * Inicializa la actualizaci�n de Lugar.
	 * @param toLugar Objeto de Transporte de Lugar
	 */
	void inicializarActualizar(DLugarTO toLugar);

	/**
	 * Inicializa la eliminaci�n de Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	void inicializarEliminar(DLugarPKTO pkLugar);

	/**
	 * Inicializa la eliminaci�n de Lugar.
	 * @param attLugar Atributos de Lugar
	 */
	void inicializarConsultaGenerica(DLugarTO toLugar);

	/**
	 * Devuelve el objeto Lugar que se haya consultado.
	 * @return Un objeto DLugarTO
	 */
	DLugarTO getLugar();

	/**
	 * Devuelve la colecci�n de objetos Lugar que se hayan consultado.
	 * @return Un Collection con objetos DLugarTO
	 */
	Collection<DLugarTO> getColeccionLugar();
}
