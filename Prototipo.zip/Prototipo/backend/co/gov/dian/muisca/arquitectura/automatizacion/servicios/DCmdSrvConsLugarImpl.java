/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;


import co.gov.dian.muisca.arquitectura.automatizacion.dao.IDDAOLugar;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.IDDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.impl.DDAOFactoryArquitectura;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para consultar un objeto Lugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvConsLugarImpl extends DCmdSrvConsLugar {

	private static final long serialVersionUID = 706758446L; 

	/**
	 * Ejecuta el comando de servicio.
	 *
	 * @throws DExcepcion Si ocurre algn error al realizar la
	 * consulta de Lugar
	 */
	protected void ejecutarComando() throws DExcepcion {
		IDAdminPersistencia admin = getAdministradorPersistencia();
		try {
			// Iniciar los DAO's
			IDDAOFactoryArquitectura fabrica = new DDAOFactoryArquitectura();
			IDDAOLugar dao = fabrica.getDaoLugar();

			// Consultar
			dao.inicializarConsultarPorPK(pkLugar);
			admin.buscar(dao);
			toLugar = dao.getLugar();
		}
		finally {
			admin.cerrarSesion();
		}
	}
}
