/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para la PK de TipoLugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DTipoLugarPKTO implements IDTO {

	private static final long serialVersionUID = -919141319L; 

  // Campos de la PK
	private java.lang.Integer ideTipoLugar;

	/**
	 * Construye un nuevo DTipoLugarPKTO por defecto.
	 */
	public DTipoLugarPKTO() { }

	/**
	 * Construye un nuevo DTipoLugarPKTO con los elementos de la llave primaria.
	 * @param ideTipoLugar java.lang.Integer
	 */
	public DTipoLugarPKTO(java.lang.Integer ideTipoLugar) {
		setIdeTipoLugar(ideTipoLugar);
	}

	/**
	 * Devuelve el valor de ideTipoLugar.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeTipoLugar() {
		return ideTipoLugar;
	}

	/**
	 * Establece el valor de ideTipoLugar.
	 * @param ideTipoLugar El nuevo valor de ideTipoLugar
	 */
	public void setIdeTipoLugar(java.lang.Integer ideTipoLugar) {
		this.ideTipoLugar = ideTipoLugar;
	}

	/**
	 * Compara el objeto actual con el objeto especificado.
	 * @param objeto Objeto con el cual se compara
	 * @return true si los objetos son iguales; false de lo contrario
	 */
	public boolean equals(Object objeto) {
		if (this == objeto) {
			return true;
		}
		if (!(objeto instanceof DTipoLugarPKTO)) {
			return false;
		}
		DTipoLugarPKTO otro = (DTipoLugarPKTO) objeto;
		EqualsBuilder builder = new EqualsBuilder();
		builder.append(getIdeTipoLugar(),  otro.getIdeTipoLugar());
		return builder.isEquals();
	}

	/**
	 * Devuelve el hash code del objeto.
	 * @return int
	 */
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();
		builder.append(getIdeTipoLugar());
		return builder.toHashCode();
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("ideTipoLugar", getIdeTipoLugar());
		return builder.toString();
	}
}
