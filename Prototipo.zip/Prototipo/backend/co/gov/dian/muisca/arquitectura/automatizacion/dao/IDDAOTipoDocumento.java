/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoTO;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para TipoDocumento.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public interface IDDAOTipoDocumento extends IDDAO {
	static final int CONSULTAR_POR_PK = 0;
	static final int CREAR = 1;
	static final int ACTUALIZAR = 2;
	static final int ELIMINAR = 3;
	static final int CONSULTA_GENERICA = 4;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	void inicializarConsultarPorPK(DTipoDocumentoPKTO pkTipoDocumento);

	/**
	 * Inicializa la creaci�n de TipoDocumento.
	 * @param toTipoDocumento Objeto de Transporte de TipoDocumento
	 */
	void inicializarCrear(DTipoDocumentoTO toTipoDocumento);

	/**
	 * Inicializa la actualizaci�n de TipoDocumento.
	 * @param toTipoDocumento Objeto de Transporte de TipoDocumento
	 */
	void inicializarActualizar(DTipoDocumentoTO toTipoDocumento);

	/**
	 * Inicializa la eliminaci�n de TipoDocumento.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	void inicializarEliminar(DTipoDocumentoPKTO pkTipoDocumento);

	/**
	 * Inicializa la eliminaci�n de TipoDocumento.
	 * @param attTipoDocumento Atributos de TipoDocumento
	 */
	void inicializarConsultaGenerica(DTipoDocumentoTO toTipoDocumento);

	/**
	 * Devuelve el objeto TipoDocumento que se haya consultado.
	 * @return Un objeto DTipoDocumentoTO
	 */
	DTipoDocumentoTO getTipoDocumento();

	/**
	 * Devuelve la colecci�n de objetos TipoDocumento que se hayan consultado.
	 * @return Un Collection con objetos DTipoDocumentoTO
	 */
	Collection<DTipoDocumentoTO> getColeccionTipoDocumento();
}
