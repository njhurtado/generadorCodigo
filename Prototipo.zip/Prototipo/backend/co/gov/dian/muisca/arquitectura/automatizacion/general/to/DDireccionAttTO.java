/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para los atributos de Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDireccionAttTO implements IDTO {
	private static final long serialVersionUID = 1123273880L; 

	// Atributos
	private java.lang.Integer idePais;
	private java.lang.Integer ideDepartamento;
	private java.lang.Integer ideMunicipio;
	private java.lang.String valDireccion;
	private java.lang.Long ideUsuarioCambio;
	private java.sql.Timestamp fecCambio;

	/**
	 * Construye un nuevo DDireccionAttTO por defecto.
	 */
	public DDireccionAttTO() { }

	/**
	 * Construye un nuevo DDireccionAttTO con los atributos.
	 * @param idePais java.lang.Integer
	 * @param ideDepartamento java.lang.Integer
	 * @param ideMunicipio java.lang.Integer
	 * @param valDireccion java.lang.String
	 * @param ideUsuarioCambio java.lang.Long
	 * @param fecCambio java.sql.Timestamp
	 */
	public DDireccionAttTO(java.lang.Integer idePais, java.lang.Integer ideDepartamento, java.lang.Integer ideMunicipio, java.lang.String valDireccion, java.lang.Long ideUsuarioCambio, java.sql.Timestamp fecCambio) {
		setIdePais(idePais);
		setIdeDepartamento(ideDepartamento);
		setIdeMunicipio(ideMunicipio);
		setValDireccion(valDireccion);
		setIdeUsuarioCambio(ideUsuarioCambio);
		setFecCambio(fecCambio);
	}

	/**
	 * Devuelve el valor de idePais.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdePais() {
		return idePais;
	}

	/**
	 * Establece el valor de idePais.
	 * @param idePais El nuevo valor de idePais
	 */
	public void setIdePais(java.lang.Integer idePais) {
		this.idePais = idePais;
	}

	/**
	 * Devuelve el valor de ideDepartamento.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeDepartamento() {
		return ideDepartamento;
	}

	/**
	 * Establece el valor de ideDepartamento.
	 * @param ideDepartamento El nuevo valor de ideDepartamento
	 */
	public void setIdeDepartamento(java.lang.Integer ideDepartamento) {
		this.ideDepartamento = ideDepartamento;
	}

	/**
	 * Devuelve el valor de ideMunicipio.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeMunicipio() {
		return ideMunicipio;
	}

	/**
	 * Establece el valor de ideMunicipio.
	 * @param ideMunicipio El nuevo valor de ideMunicipio
	 */
	public void setIdeMunicipio(java.lang.Integer ideMunicipio) {
		this.ideMunicipio = ideMunicipio;
	}

	/**
	 * Devuelve el valor de valDireccion.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getValDireccion() {
		return valDireccion;
	}

	/**
	 * Establece el valor de valDireccion.
	 * @param valDireccion El nuevo valor de valDireccion
	 */
	public void setValDireccion(java.lang.String valDireccion) {
		this.valDireccion = valDireccion;
	}

	/**
	 * Devuelve el valor de ideUsuarioCambio.
	 * @return Un objeto java.lang.Long
	 */
	public java.lang.Long getIdeUsuarioCambio() {
		return ideUsuarioCambio;
	}

	/**
	 * Establece el valor de ideUsuarioCambio.
	 * @param ideUsuarioCambio El nuevo valor de ideUsuarioCambio
	 */
	public void setIdeUsuarioCambio(java.lang.Long ideUsuarioCambio) {
		this.ideUsuarioCambio = ideUsuarioCambio;
	}

	/**
	 * Devuelve el valor de fecCambio.
	 * @return Un objeto java.sql.Timestamp
	 */
	public java.sql.Timestamp getFecCambio() {
		return fecCambio;
	}

	/**
	 * Establece el valor de fecCambio.
	 * @param fecCambio El nuevo valor de fecCambio
	 */
	public void setFecCambio(java.sql.Timestamp fecCambio) {
		this.fecCambio = fecCambio;
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("idePais", getIdePais());
		builder.append("ideDepartamento", getIdeDepartamento());
		builder.append("ideMunicipio", getIdeMunicipio());
		builder.append("valDireccion", getValDireccion());
		builder.append("ideUsuarioCambio", getIdeUsuarioCambio());
		builder.append("fecCambio", getFecCambio());
		return builder.toString();
	}
}
