/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para consultar objetos TipoDocumento.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvConsLstTipoDocumento extends DComandoServicioInterno {
	private static final long serialVersionUID = -1032269976L; 


	public static final int CONSULTA_GENERICA = 0;


	protected DTipoDocumentoTO toTipoDocumento;

	/** Tipo de operaci�n de consulta */
	protected int tipoOperacion = -1;
	/** Colecci�n de objetos DTipoDocumentoTO */
	protected Collection<DTipoDocumentoTO> objetosTipoDocumento;


	/**
	 * Inicializa la consulta gen�rica de TipoDocumento.
	 * @param attTipoDocumento Atributos de TipoDocumento
	 */
	public void inicializarConsultaGenerica(DTipoDocumentoTO toTipoDocumento) {
		tipoOperacion = CONSULTA_GENERICA;
		this.toTipoDocumento = toTipoDocumento;
	}

	/**
	 * Devuelve la colecci�n de objetos TipoDocumento que se hayan consultado.
	 * @return Un Collection con objetos DTipoDocumentoTO
	 */
	public Collection<DTipoDocumentoTO> getColeccionTipoDocumento() {
		return objetosTipoDocumento;
	}

	/**
	 * Ejecuta el comando de servicio.
	 * @throws DExcepcion Si ocurre alg�n error al realizar la
	 * la consulta de TipoDocumento
	 */
	protected void ejecutarComando() throws DExcepcion {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdSrvConsLstTipoDocumento();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite consultar objetos TipoDocumento";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los paretros son v�idos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�idos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (tipoOperacion) {

			case CONSULTA_GENERICA:
				parametros.put(this.getClass().getName()+":validar:toTipoDocumento",toTipoDocumento);
				break;

			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos TipoDocumento"), getMensajeOperInvalida());
		}
		validarParametros("Listar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdSrvConsLstTipoDocumento) {
			DCmdSrvConsLstTipoDocumento copia = (DCmdSrvConsLstTipoDocumento) comando;
			copia.tipoOperacion = tipoOperacion;
			copia.objetosTipoDocumento = objetosTipoDocumento;
			copia.toTipoDocumento = toTipoDocumento;
		}
	}
}
