/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para actualizar un objeto Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccActDireccion extends DComandoAccion {
	private static final long serialVersionUID = 1724029609L; 

	/** Objeto de transporte de Direccion */
	protected DDireccionTO toDireccion;
	/** Llave primaria de Direccion */
	protected DDireccionPKTO pkDireccion;
	/** Atributos de Direccion */
	protected DDireccionAttTO attDireccion;

	/**
	 * Inicializa la actualizaci�n de Direccion.
	 * @param toDireccion Objeto de Transporte de Direccion
	 */
	public void inicializar(DDireccionTO toDireccion) {
		isOk = false;
		this.toDireccion = toDireccion;
		if (toDireccion != null) {
			pkDireccion = this.toDireccion.getPK();
			attDireccion = this.toDireccion.getAtt();
		}
	}

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdAccActDireccion();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite actualizar un objeto Direccion";
	}

	/**
	 * M�odo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		parametros.put(this.getClass().getName()+":validar:toDireccion",toDireccion);
		parametros.put(this.getClass().getName()+":validar:pkDireccion",pkDireccion);
		parametros.put(this.getClass().getName()+":validar:attDireccion",attDireccion);
		parametros.put(this.getClass().getName()+":validar:pkDireccion.getIdeDireccion()",pkDireccion.getIdeDireccion());
		parametros.put(this.getClass().getName()+":validar:attDireccion.getIdePais()",attDireccion.getIdePais());
		parametros.put(this.getClass().getName()+":validar:attDireccion.getIdeDepartamento()",attDireccion.getIdeDepartamento());
		parametros.put(this.getClass().getName()+":validar:attDireccion.getIdeMunicipio()",attDireccion.getIdeMunicipio());
		parametros.put(this.getClass().getName()+":validar:attDireccion.getValDireccion()",attDireccion.getValDireccion());
		parametros.put(this.getClass().getName()+":validar:attDireccion.getIdeUsuarioCambio()",attDireccion.getIdeUsuarioCambio());
		parametros.put(this.getClass().getName()+":validar:attDireccion.getFecCambio()",attDireccion.getFecCambio());
		validarParametros("Actualizar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdAccActDireccion) {
			DCmdAccActDireccion copia = (DCmdAccActDireccion) comando;
			copia.toDireccion = toDireccion;
			copia.pkDireccion = pkDireccion;
			copia.attDireccion = attDireccion;
		}
	}
}
