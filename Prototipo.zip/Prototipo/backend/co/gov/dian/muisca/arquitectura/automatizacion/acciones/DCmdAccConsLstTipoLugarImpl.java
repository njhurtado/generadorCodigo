/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import co.gov.dian.muisca.arquitectura.automatizacion.servicios.DCmdSrvConsLstTipoLugar;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;
import co.gov.dian.muisca.arquitectura.acciones.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar objetos TipoLugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsLstTipoLugarImpl extends DCmdAccConsLstTipoLugar {
	private static final long serialVersionUID = 1758075433L; 

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		try {
			DCmdSrvConsLstTipoLugar servicio = (DCmdSrvConsLstTipoLugar) getServicio("arquitectura.automatizacion.DCmdSrvConsLstTipoLugar");
			servicio.setPaginable(true);
			switch (tipoOperacion) {

			case CONSULTA_GENERICA:
				servicio.inicializarConsultaGenerica(toTipoLugar);
				break;


			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos TipoLugar"), getMensajeOperInvalida());
			}
			servicio.ejecutar();
			objetosTipoLugar = servicio.getColeccionTipoLugar();
			isOk = true;
		}
		catch (DExcepcion ex) {
			mensajeError = ex.getMessage();
			mensajeErrorDetallado = ex.getMensajeDetallado();
			isOk = false;
		}
	}
}
