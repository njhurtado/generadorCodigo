/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarPKTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para consultar objetos Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvConsLstDireccion extends DComandoServicioInterno {
	private static final long serialVersionUID = 2014815928L; 

	public static final int CONSULTAR_POR_LUGAR = 0;
	public static final int CONSULTAR_POR_LUGAR = 1;

	public static final int CONSULTA_GENERICA = 2;

	/** Llave primaria de Lugar */
	protected DLugarPKTO pkLugar;
	/** Llave primaria de Lugar */
	protected DLugarPKTO pkLugar;

	protected DDireccionTO toDireccion;

	/** Tipo de operaci�n de consulta */
	protected int tipoOperacion = -1;
	/** Colecci�n de objetos DDireccionTO */
	protected Collection<DDireccionTO> objetosDireccion;

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	public void inicializarConsultarPorLugar(DLugarPKTO pkLugar) {
		tipoOperacion = CONSULTAR_POR_LUGAR;
		this.pkLugar = pkLugar;
		objetosDireccion = null;
	}
	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	public void inicializarConsultarPorLugar(DLugarPKTO pkLugar) {
		tipoOperacion = CONSULTAR_POR_LUGAR;
		this.pkLugar = pkLugar;
		objetosDireccion = null;
	}

	/**
	 * Inicializa la consulta gen�rica de Direccion.
	 * @param attDireccion Atributos de Direccion
	 */
	public void inicializarConsultaGenerica(DDireccionTO toDireccion) {
		tipoOperacion = CONSULTA_GENERICA;
		this.toDireccion = toDireccion;
	}

	/**
	 * Devuelve la colecci�n de objetos Direccion que se hayan consultado.
	 * @return Un Collection con objetos DDireccionTO
	 */
	public Collection<DDireccionTO> getColeccionDireccion() {
		return objetosDireccion;
	}

	/**
	 * Ejecuta el comando de servicio.
	 * @throws DExcepcion Si ocurre alg�n error al realizar la
	 * la consulta de Direccion
	 */
	protected void ejecutarComando() throws DExcepcion {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdSrvConsLstDireccion();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite consultar objetos Direccion";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los paretros son v�idos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�idos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (tipoOperacion) {
			case CONSULTAR_POR_LUGAR:
				parametros.put(this.getClass().getName()+":validar:pkLugar",pkLugar);
				parametros.put(this.getClass().getName()+":validar:pkLugar.getIdeLugar()",pkLugar.getIdeLugar());
				break;
			case CONSULTAR_POR_LUGAR:
				parametros.put(this.getClass().getName()+":validar:pkLugar",pkLugar);
				parametros.put(this.getClass().getName()+":validar:pkLugar.getIdeLugar()",pkLugar.getIdeLugar());
				break;

			case CONSULTA_GENERICA:
				parametros.put(this.getClass().getName()+":validar:toDireccion",toDireccion);
				break;

			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos Direccion"), getMensajeOperInvalida());
		}
		validarParametros("Listar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdSrvConsLstDireccion) {
			DCmdSrvConsLstDireccion copia = (DCmdSrvConsLstDireccion) comando;
			copia.tipoOperacion = tipoOperacion;
			copia.pkLugar = pkLugar;
			copia.pkLugar = pkLugar;
			copia.objetosDireccion = objetosDireccion;
			copia.toDireccion = toDireccion;
		}
	}
}
