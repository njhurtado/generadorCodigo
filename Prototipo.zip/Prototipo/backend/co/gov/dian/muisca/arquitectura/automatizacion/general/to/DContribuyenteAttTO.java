/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para los atributos de Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DContribuyenteAttTO implements IDTO {
	private static final long serialVersionUID = -1231029142L; 

	// Atributos
	private java.lang.String nomPrimerNombre;
	private java.lang.String nomOtrosNombres;
	private java.lang.String nomPrimerApellido;
	private java.lang.String nomSegundoApellido;
	private java.lang.String nomRazonSocial;
	private java.lang.Integer ideTipoDocumento;
	private java.lang.String numIdentidad;
	private java.lang.Long numNit;
	private java.lang.Long ideUsuarioCambio;
	private java.sql.Timestamp fecCambio;

	/**
	 * Construye un nuevo DContribuyenteAttTO por defecto.
	 */
	public DContribuyenteAttTO() { }

	/**
	 * Construye un nuevo DContribuyenteAttTO con los atributos.
	 * @param nomPrimerNombre java.lang.String
	 * @param nomOtrosNombres java.lang.String
	 * @param nomPrimerApellido java.lang.String
	 * @param nomSegundoApellido java.lang.String
	 * @param nomRazonSocial java.lang.String
	 * @param ideTipoDocumento java.lang.Integer
	 * @param numIdentidad java.lang.String
	 * @param numNit java.lang.Long
	 * @param ideUsuarioCambio java.lang.Long
	 * @param fecCambio java.sql.Timestamp
	 */
	public DContribuyenteAttTO(java.lang.String nomPrimerNombre, java.lang.String nomOtrosNombres, java.lang.String nomPrimerApellido, java.lang.String nomSegundoApellido, java.lang.String nomRazonSocial, java.lang.Integer ideTipoDocumento, java.lang.String numIdentidad, java.lang.Long numNit, java.lang.Long ideUsuarioCambio, java.sql.Timestamp fecCambio) {
		setNomPrimerNombre(nomPrimerNombre);
		setNomOtrosNombres(nomOtrosNombres);
		setNomPrimerApellido(nomPrimerApellido);
		setNomSegundoApellido(nomSegundoApellido);
		setNomRazonSocial(nomRazonSocial);
		setIdeTipoDocumento(ideTipoDocumento);
		setNumIdentidad(numIdentidad);
		setNumNit(numNit);
		setIdeUsuarioCambio(ideUsuarioCambio);
		setFecCambio(fecCambio);
	}

	/**
	 * Devuelve el valor de nomPrimerNombre.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomPrimerNombre() {
		return nomPrimerNombre;
	}

	/**
	 * Establece el valor de nomPrimerNombre.
	 * @param nomPrimerNombre El nuevo valor de nomPrimerNombre
	 */
	public void setNomPrimerNombre(java.lang.String nomPrimerNombre) {
		this.nomPrimerNombre = nomPrimerNombre;
	}

	/**
	 * Devuelve el valor de nomOtrosNombres.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomOtrosNombres() {
		return nomOtrosNombres;
	}

	/**
	 * Establece el valor de nomOtrosNombres.
	 * @param nomOtrosNombres El nuevo valor de nomOtrosNombres
	 */
	public void setNomOtrosNombres(java.lang.String nomOtrosNombres) {
		this.nomOtrosNombres = nomOtrosNombres;
	}

	/**
	 * Devuelve el valor de nomPrimerApellido.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomPrimerApellido() {
		return nomPrimerApellido;
	}

	/**
	 * Establece el valor de nomPrimerApellido.
	 * @param nomPrimerApellido El nuevo valor de nomPrimerApellido
	 */
	public void setNomPrimerApellido(java.lang.String nomPrimerApellido) {
		this.nomPrimerApellido = nomPrimerApellido;
	}

	/**
	 * Devuelve el valor de nomSegundoApellido.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomSegundoApellido() {
		return nomSegundoApellido;
	}

	/**
	 * Establece el valor de nomSegundoApellido.
	 * @param nomSegundoApellido El nuevo valor de nomSegundoApellido
	 */
	public void setNomSegundoApellido(java.lang.String nomSegundoApellido) {
		this.nomSegundoApellido = nomSegundoApellido;
	}

	/**
	 * Devuelve el valor de nomRazonSocial.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNomRazonSocial() {
		return nomRazonSocial;
	}

	/**
	 * Establece el valor de nomRazonSocial.
	 * @param nomRazonSocial El nuevo valor de nomRazonSocial
	 */
	public void setNomRazonSocial(java.lang.String nomRazonSocial) {
		this.nomRazonSocial = nomRazonSocial;
	}

	/**
	 * Devuelve el valor de ideTipoDocumento.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeTipoDocumento() {
		return ideTipoDocumento;
	}

	/**
	 * Establece el valor de ideTipoDocumento.
	 * @param ideTipoDocumento El nuevo valor de ideTipoDocumento
	 */
	public void setIdeTipoDocumento(java.lang.Integer ideTipoDocumento) {
		this.ideTipoDocumento = ideTipoDocumento;
	}

	/**
	 * Devuelve el valor de numIdentidad.
	 * @return Un objeto java.lang.String
	 */
	public java.lang.String getNumIdentidad() {
		return numIdentidad;
	}

	/**
	 * Establece el valor de numIdentidad.
	 * @param numIdentidad El nuevo valor de numIdentidad
	 */
	public void setNumIdentidad(java.lang.String numIdentidad) {
		this.numIdentidad = numIdentidad;
	}

	/**
	 * Devuelve el valor de numNit.
	 * @return Un objeto java.lang.Long
	 */
	public java.lang.Long getNumNit() {
		return numNit;
	}

	/**
	 * Establece el valor de numNit.
	 * @param numNit El nuevo valor de numNit
	 */
	public void setNumNit(java.lang.Long numNit) {
		this.numNit = numNit;
	}

	/**
	 * Devuelve el valor de ideUsuarioCambio.
	 * @return Un objeto java.lang.Long
	 */
	public java.lang.Long getIdeUsuarioCambio() {
		return ideUsuarioCambio;
	}

	/**
	 * Establece el valor de ideUsuarioCambio.
	 * @param ideUsuarioCambio El nuevo valor de ideUsuarioCambio
	 */
	public void setIdeUsuarioCambio(java.lang.Long ideUsuarioCambio) {
		this.ideUsuarioCambio = ideUsuarioCambio;
	}

	/**
	 * Devuelve el valor de fecCambio.
	 * @return Un objeto java.sql.Timestamp
	 */
	public java.sql.Timestamp getFecCambio() {
		return fecCambio;
	}

	/**
	 * Establece el valor de fecCambio.
	 * @param fecCambio El nuevo valor de fecCambio
	 */
	public void setFecCambio(java.sql.Timestamp fecCambio) {
		this.fecCambio = fecCambio;
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("nomPrimerNombre", getNomPrimerNombre());
		builder.append("nomOtrosNombres", getNomOtrosNombres());
		builder.append("nomPrimerApellido", getNomPrimerApellido());
		builder.append("nomSegundoApellido", getNomSegundoApellido());
		builder.append("nomRazonSocial", getNomRazonSocial());
		builder.append("ideTipoDocumento", getIdeTipoDocumento());
		builder.append("numIdentidad", getNumIdentidad());
		builder.append("numNit", getNumNit());
		builder.append("ideUsuarioCambio", getIdeUsuarioCambio());
		builder.append("fecCambio", getFecCambio());
		return builder.toString();
	}
}
