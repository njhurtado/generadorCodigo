/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para la PK de Direccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDireccionPKTO implements IDTO {

	private static final long serialVersionUID = 851191757L; 

  // Campos de la PK
	private java.lang.Long ideDireccion;

	/**
	 * Construye un nuevo DDireccionPKTO por defecto.
	 */
	public DDireccionPKTO() { }

	/**
	 * Construye un nuevo DDireccionPKTO con los elementos de la llave primaria.
	 * @param ideDireccion java.lang.Long
	 */
	public DDireccionPKTO(java.lang.Long ideDireccion) {
		setIdeDireccion(ideDireccion);
	}

	/**
	 * Devuelve el valor de ideDireccion.
	 * @return Un objeto java.lang.Long
	 */
	public java.lang.Long getIdeDireccion() {
		return ideDireccion;
	}

	/**
	 * Establece el valor de ideDireccion.
	 * @param ideDireccion El nuevo valor de ideDireccion
	 */
	public void setIdeDireccion(java.lang.Long ideDireccion) {
		this.ideDireccion = ideDireccion;
	}

	/**
	 * Compara el objeto actual con el objeto especificado.
	 * @param objeto Objeto con el cual se compara
	 * @return true si los objetos son iguales; false de lo contrario
	 */
	public boolean equals(Object objeto) {
		if (this == objeto) {
			return true;
		}
		if (!(objeto instanceof DDireccionPKTO)) {
			return false;
		}
		DDireccionPKTO otro = (DDireccionPKTO) objeto;
		EqualsBuilder builder = new EqualsBuilder();
		builder.append(getIdeDireccion(),  otro.getIdeDireccion());
		return builder.isEquals();
	}

	/**
	 * Devuelve el hash code del objeto.
	 * @return int
	 */
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();
		builder.append(getIdeDireccion());
		return builder.toHashCode();
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("ideDireccion", getIdeDireccion());
		return builder.toString();
	}
}
