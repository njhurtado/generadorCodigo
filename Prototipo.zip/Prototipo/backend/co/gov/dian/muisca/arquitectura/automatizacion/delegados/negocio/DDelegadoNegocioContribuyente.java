package co.gov.dian.muisca.arquitectura.automatizacion.delegados.negocio;

import co.gov.dian.muisca.arquitectura.acciones.valoresdominio.DCmdAccConsValorDominio;
import co.gov.dian.muisca.arquitectura.auditoria.delegados.general.DDelegadoNegocio;
import co.gov.dian.muisca.arquitectura.auditoria.general.excepciones.mensajes.DMensajesAuditoria;
import co.gov.dian.muisca.arquitectura.automatizacion.acciones.*;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.*;
import co.gov.dian.muisca.arquitectura.general.excepcion.DExcepcion;
import co.gov.dian.muisca.arquitectura.general.excepcion.DMuiscaAppException;
import co.gov.dian.muisca.arquitectura.general.excepcion.errores.tipos.DConfirmacionErrorInfo;
import co.gov.dian.muisca.arquitectura.general.excepcion.errores.tipos.DIrrecuperableErrorInfo;
import co.gov.dian.muisca.arquitectura.general.excepcion.errores.tipos.DValidacionWebErrorInfo;
import co.gov.dian.muisca.arquitectura.general.excepcion.mensajes.enums.DMensajesGeneral;
import co.gov.dian.muisca.arquitectura.general.formateador.implgenerica.DFechaHora;
import co.gov.dian.muisca.arquitectura.general.to.gdto.DGenericoDTO;
import co.gov.dian.muisca.arquitectura.general.to.segmentacion.DSegmentoAplicacionPKTO;
import co.gov.dian.muisca.arquitectura.general.to.tablasbasicas.DValorDominioAttTO;
import co.gov.dian.muisca.arquitectura.web.buses.DContextoSeguridad;
import co.gov.dian.muisca.rut.acciones.DCmdAccConsPersonaRut;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Clase delegada concreta a un aspecto de negocio su nombramiento es DDelegadoNegocio en este caso
 * Auditoria
 */
public class DDelegadoNegocioContribuyente extends DDelegadoNegocio {

    private static Logger logger = Logger.getLogger( DDelegadoNegocioContribuyente.class );

    public DDelegadoNegocioContribuyente( DContextoSeguridad contextoSeguridad, List emisoresComando, DSegmentoAplicacionPKTO pkSegmentoApp ) {
        super( contextoSeguridad, emisoresComando, pkSegmentoApp );
    }

    public DGenericoDTO buscarTiposDocumentos( DGenericoDTO dto ) throws DMuiscaAppException {

        logger.debug( "************  buscarTiposDocumentos ***********************" );
        try {
            DCmdAccConsValorDominio valorDominio = ( DCmdAccConsValorDominio )this.getAccion( "arquitectura.valoresdominio.DCmdAccConsValorDominio" );

            DValorDominioAttTO valorAtt = new DValorDominioAttTO( );
            //Valor Dominio para tipos de documento
            valorAtt.setCodDominio( 109 );
            //Se coloca la fecha actual para que cargue los valores de acuerdo a la vigencia
            Integer fecActual = DFechaHora.convertirDateToInteger( new Date( ) );
            valorAtt.setFechaDesde( fecActual );
            valorAtt.setFechaHasta( fecActual );
            valorDominio.inicializarConsultaPorATT( valorAtt );
            valorDominio.ejecutar( );
            Collection dominioCollection = valorDominio.getValoresDominio( );

            if( dominioCollection != null ) {

            }
            List dominiosList = dominioCollection instanceof List ? ( List )dominioCollection : new ArrayList( dominioCollection );
            dto.addList( "tiposIdentList", dominiosList );

        }
        catch( DExcepcion ex ) {
            String error = String.format( "Error Accion:] La Accion :  %s tiene una problema de Ejecuci?n", "" );
            throw new DMuiscaAppException( ex, new DIrrecuperableErrorInfo( error, DMensajesGeneral.ERROR_ACCION ) );
        }

        return dto;

    }

    public DGenericoDTO buscarContribuyente( DGenericoDTO dto ) throws DMuiscaAppException {

        try {

            //Busqueda de la Persona en el RUT
            DCmdAccConsPersonaRut consPersonaRut = ( DCmdAccConsPersonaRut )this.getAccion( "rut.DCmdAccConsPersonaRut", false );
            consPersonaRut.inicializarConsultarPorIdentificacion( dto.getLongValue( "idTipoDocumento" ).intValue( ), dto.getLongValue( "numNit" ).toString( ) );
            consPersonaRut.ejecutar( );

            //Validar el contenido si se encontro o no la persona
            if( consPersonaRut.getPersonaRut( ) != null ) {
                dto.addString( "nomRazonSocial", consPersonaRut.getPersonaRut( ).getAtt( ).getNomRazonSocial( ) );
                dto.addLong( "idPersonaRut", consPersonaRut.getMascaraRut( ).getPK( ).getIdePersonaRut( ) );
            }
            else {
                String error = String.format( "Persona con Tipo de Documento : [%s] e Identificacion No [ %s ] no existe en el RUT", dto.getStringValue( "tipoDocumento" ), dto.getLongValue( "numNit" ).toString( ) );
                throw new DMuiscaAppException( new DValidacionWebErrorInfo( error, DMensajesGeneral.ERROR_ACCION, dto.getLongValue( "idTipoDocumento" ).intValue( ), dto.getLongValue( "numNit" ).toString( ) ) );
            }

        }
        catch( DExcepcion ex ) {
            String error = String.format( "Error - Las Acci�n [ %s ] tiene un Problema de Ejecuci�n - Parametros:[%s]", "DCmdAccConsPersonaRut", dto.toString( ) );
            throw new DMuiscaAppException( ex, new DIrrecuperableErrorInfo( error, DMensajesGeneral.ERROR_ACCION ) );
        }

        return dto;
    }

    public void crearContribuyenteMuisca( DGenericoDTO dto ) throws DMuiscaAppException {

        logger.debug( "************  crearContribuyenteMuisca   ***********************" );

        //Se genera la habilitacion de la cuenta Muisca
        try {

            //Creacion del Contribuyente
            DCmdAccCrearContribuyente accCrearContribuyente = ( DCmdAccCrearContribuyente )this.getAccion( "arquitectura.DCmdAccCrearContribuyente" );
            DContribuyenteTO toContribuyente = new DContribuyenteTO( );

            DContribuyentePKTO contribuyentePKTO = new DContribuyentePKTO( );

            DContribuyenteAttTO contribuyenteAttTO = new DContribuyenteAttTO( );
            contribuyenteAttTO.setNumIdentidad( dto.get( "numIdentidad" ).getValue( ).toString( ) );
            accCrearContribuyente.inicializar( toContribuyente );
            accCrearContribuyente.ejecutar( );

            //Creacion de la direccion
            DCmdAccCrearDireccion accCrearDireccion = ( DCmdAccCrearDireccion )this.getAccion( "arquitectura.DCmdAccCrearDireccion" );
            DDireccionTO toDireccion = new DDireccionTO( );
            accCrearDireccion.inicializar( toDireccion );
            accCrearDireccion.ejecutar( );

            //Creacion Maestro - Detalle
            DCmdAccCrearContribuyenteDireccion accCrearcontribuyenteDireccion = ( DCmdAccCrearContribuyenteDireccion )this.getAccion( "arquitectura.DCmdAccCrearContribuyenteDireccion" );
            DContribuyenteDireccionTO toContribuyenteDireccion = new DContribuyenteDireccionTO( );
            toContribuyenteDireccion.setPK( new DContribuyenteDireccionPKTO( new Long( accCrearContribuyente.getDescripcion( ) ), new Long( accCrearDireccion.getDescripcion( ) ) ) );
            accCrearcontribuyenteDireccion.inicializar( toContribuyenteDireccion );
            accCrearcontribuyenteDireccion.ejecutar( );

        }
        catch( DExcepcion ex ) {
            String error = String.format( "Las Acci�n [ %s ] tiene un Problema de Ejecuci�n : [%s] - Parametros : [idPersonaRut = %s]", "crearContribuyenteMuisca", ex.getMensajeDetallado( ), dto.getLongValue( "idPersonaRut" ) );
            DMuiscaAppException musicaException = new DMuiscaAppException( ex, new DIrrecuperableErrorInfo( error, DMensajesGeneral.ERROR_ACCION ) );
            String errorWeb = String.format( "Error Irrecuperable en el Servicio de Creacion de contribuyente Muisca, por favor comunicarse al area de soporte tecnol�gico de la entidad [ Codigo de Error : [%s] ]", DMensajesGeneral.ERROR_ACCION );
            musicaException.getErrors( ).add( new DValidacionWebErrorInfo( errorWeb, DMensajesGeneral.ERROR_ACCION ) );
            throw musicaException;
        }

        //Lanzamiento de una Excepcion de Confirmacion - Funcionamiento Correcto de la funcion

        String confirmacion = String.format( "Se ha creado el contribuyente  MUISCA con Identificaci�n: [ %s ] - Usuario: [%s]", dto.getLongValue( "numNit" ), dto.getStringValue( "nomRazonSocial" ) );
        throw new DMuiscaAppException( new DConfirmacionErrorInfo( confirmacion, DMensajesAuditoria.RESETEO_CUENTA_EXITOSO ) );

    }

    public void borrarContribuyenteMuisca( DGenericoDTO dto ) throws DMuiscaAppException {

        logger.debug( "************  borrarContribuyenteMuisca  ***********************" );

        //Se genera la habilitacion de la cuenta Muisca
        try {
            // Se elimina  Maestro - Detalle
            DCmdAccElimContribuyenteDireccion accElimContribuyenteDireccion = ( DCmdAccElimContribuyenteDireccion )this.getAccion( "arquitectura.DCmdAccElimContribuyenteDireccion" );
            accElimContribuyenteDireccion.inicializar( new DContribuyenteDireccionPKTO( dto.getLongValue( "idPersonaRut" ), dto.getLongValue( "idDireccion" ) ) );
            accElimContribuyenteDireccion.ejecutar( );

            // Se elimina la Direccion
            DCmdAccElimDireccion accElimDireccion = ( DCmdAccElimDireccion )this.getAccion( "arquitectura.DCmdAccElimDireccion" );
            accElimDireccion.inicializar( new DDireccionPKTO( dto.getLongValue( "idDireccion" ) ) );
            accElimDireccion.ejecutar( );

            //Se elimina el contribuyente
            DCmdAccElimContribuyente accElimContribuyente = ( DCmdAccElimContribuyente )this.getAccion( "arquitectura.DCmdAccElimContribuyente" );
            accElimContribuyente.inicializar( new DDireccionPKTO( dto.getLongValue( "idPersonaRut" ) ) );
            accElimContribuyente.ejecutar( );

        }
        catch( DExcepcion ex ) {

            String error = String.format( "Las Acci�n [ %s ] tiene un Problema de Ejecuci�n : [%s] - Parametros : [idPersonaRut = %s]", "borrarContribuyenteMuisca", ex.getMensajeDetallado( ), dto.getLongValue( "idPersonaRut" ) );
            DMuiscaAppException musicaException = new DMuiscaAppException( ex, new DIrrecuperableErrorInfo( error, DMensajesGeneral.ERROR_ACCION ) );
            String errorWeb = String.format( "Error Irrecuperable en el Servicio de Eliminacion de Contribuyente Muisca, por favor comunicarse al area de soporte tecnol�gico de la entidad [ Codigo de Error : [%s] ]", DMensajesGeneral.ERROR_ACCION );
            musicaException.getErrors( ).add( new DValidacionWebErrorInfo( errorWeb, DMensajesGeneral.ERROR_ACCION ) );
            throw musicaException;
        }

        //Lanzamiento de una Excepcion de Confirmacion - Funcionamiento Correcto de la funcion

        String confirmacion = String.format( "Se ha Eliminado el contribuyente Identificaci�n: [ %s ] - Usuario: [%s]", dto.getLongValue( "numNit" ), dto.getStringValue( "nomRazonSocial" ) );
        throw new DMuiscaAppException( new DConfirmacionErrorInfo( confirmacion, DMensajesAuditoria.RESETEO_CUENTA_EXITOSO ) );

    }

    public void actualizarContribuyenteMuisca( DGenericoDTO dto ) throws DMuiscaAppException {

        logger.debug( "************  actualizarContribuyenteMuisca   ***********************" );

        //Se genera la habilitacion de la cuenta Muisca
        try {
            DCmdAccActContribuyente accActualizarContribuyente = ( DCmdAccActContribuyente )this.getAccion( "arquitectura.DCmdAccActContribuyente" );
            accActualizarContribuyente.inicializar( new DContribuyenteTO( dto.getLongValue( "idPersonaRut" ) ) );
            accActualizarContribuyente.ejecutar( );

        }
        catch( DExcepcion ex ) {
            String error = String.format( "Las Acci�n [ %s ] tiene un Problema de Ejecuci�n : [%s] - Parametros : [idPersonaRut = %s]", "actualizarContribuyenteMuisca", ex.getMensajeDetallado( ), dto.getLongValue( "idPersonaRut" ) );
            DMuiscaAppException musicaException = new DMuiscaAppException( ex, new DIrrecuperableErrorInfo( error, DMensajesGeneral.ERROR_ACCION ) );
            String errorWeb = String
                    .format( "Error Irrecuperable en el Servicio de actualizacion de Contribuyente Muisca, por favor comunicarse al area de soporte tecnol�gico de la entidad [ Codigo de Error : [%s] ]", DMensajesGeneral.ERROR_ACCION );
            musicaException.getErrors( ).add( new DValidacionWebErrorInfo( errorWeb, DMensajesGeneral.ERROR_ACCION ) );
            throw musicaException;
        }

        //Lanzamiento de una Excepcion de Confirmacion - Funcionamiento Correcto de la funcion

        String confirmacion = String.format( "Se ha Actualizado el contribuyente MUISCA con Identificaci�n: [ %s ] - Usuario: [%s]", dto.getLongValue( "numNit" ), dto.getStringValue( "nomRazonSocial" ) );
        throw new DMuiscaAppException( new DConfirmacionErrorInfo( confirmacion, DMensajesAuditoria.RESETEO_CUENTA_EXITOSO ) );

    }

    public void actualizarDireccionContribuyenteMuisca( DGenericoDTO dto ) throws DMuiscaAppException {

        logger.debug( "************  actualizarDireccionContribuyenteMuisca  ***********************" );

        //Se genera la habilitacion de la cuenta Muisca
        try {
            DCmdAccActDireccion accResetCuenta = ( DCmdAccActDireccion )this.getAccion( "arquitectura.DCmdAccActDireccion" );
            accResetCuenta.inicializar( new DDireccionTO( new DDireccionPKTO( dto.getLongValue( "idPersonaRut" ) ) ) );
            accResetCuenta.ejecutar( );

        }
        catch( DExcepcion ex ) {
            String error = String.format( "Las Acci�n [ %s ] tiene un Problema de Ejecuci�n : [%s] - Parametros : [idPersonaRut = %s]", "actualizarDireccionContribuyenteMuisca", ex.getMensajeDetallado( ), dto.getLongValue( "idPersonaRut" ) );
            DMuiscaAppException musicaException = new DMuiscaAppException( ex, new DIrrecuperableErrorInfo( error, DMensajesGeneral.ERROR_ACCION ) );
            String errorWeb = String
                    .format( "Error Irrecuperable en el Servicio de Actualizar Direci�n de contribuyente Muisca, por favor comunicarse al area de soporte tecnol�gico de la entidad [ Codigo de Error : [%s] ]", DMensajesGeneral.ERROR_ACCION );
            musicaException.getErrors( ).add( new DValidacionWebErrorInfo( errorWeb, DMensajesGeneral.ERROR_ACCION ) );
            throw musicaException;
        }

        //Lanzamiento de una Excepcion de Confirmacion - Funcionamiento Correcto de la funcion

        String confirmacion = String.format( "Se ha Actualizado las Direcciones del contribuyente MUISCA con Identificaci�n: [ %s ] - Usuario: [%s]", dto.getLongValue( "numNit" ), dto.getStringValue( "nomRazonSocial" ) );
        throw new DMuiscaAppException( new DConfirmacionErrorInfo( confirmacion, DMensajesAuditoria.RESETEO_CUENTA_EXITOSO ) );

    }

}