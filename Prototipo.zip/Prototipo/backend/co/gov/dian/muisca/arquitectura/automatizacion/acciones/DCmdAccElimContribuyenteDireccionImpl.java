/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import co.gov.dian.muisca.arquitectura.automatizacion.servicios.DCmdSrvElimContribuyenteDireccion;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;
import co.gov.dian.muisca.arquitectura.acciones.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para eliminar un objeto ContribuyenteDireccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccElimContribuyenteDireccionImpl extends DCmdAccElimContribuyenteDireccion {
	private static final long serialVersionUID = 719845582L; 

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		try {
			DCmdSrvElimContribuyenteDireccion servicio = (DCmdSrvElimContribuyenteDireccion) getServicio("arquitectura.automatizacion.DCmdSrvElimContribuyenteDireccion");
			servicio.inicializar(pkContribuyenteDireccion);
			servicio.ejecutar();
			isOk = true;
		}
		catch (DExcepcion ex) {
			mensajeError = ex.getMessage();
			mensajeErrorDetallado = ex.getMensajeDetallado();
			isOk = false;
		}
	}
}
