/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.sql.*;
import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DLugarTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarPKTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.general.persistencia.dao.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.dataset.*;
import co.gov.dian.muisca.arquitectura.mensajes.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para Lugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDAOLugar extends DDAO implements IDDAOLugar {
	/** colecci�n de objetos DLugarTO */
	private Collection<DLugarTO> objetosLugar;
	/** Objeto de transporte de Lugar */
	private DLugarTO toLugar;
	/** Llave primaria de Lugar */
	private DLugarPKTO pkLugar;
	/** Atributos de Lugar */
	private DLugarAttTO attLugar;
	/** Llave primaria de TipoLugar */
	private DTipoLugarPKTO pkTipoLugar;
	/** Llave primaria de Lugar */
	private DLugarPKTO pkLugar;
	/** Llave primaria de Lugar */
	private DLugarPKTO pkLugar;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkLugar Llave primaria de Lugar
	 */
	public void inicializarConsultarPorPK(DLugarPKTO pkLugar) {
		setTipoOperacion(CONSULTAR_POR_PK);
		this.pkLugar = pkLugar;
	}

	/**
	 * Inicializa la consulta por TipoLugar.
	 * @param pkTipoLugar Llave primaria de TipoLugar
	 */
	public void inicializarConsultarPorTipoLugar(DTipoLugarPKTO pkTipoLugar) {
		setTipoOperacion(CONSULTAR_POR_TIPOLUGAR);
		this.pkTipoLugar = pkTipoLugar;
	}

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	public void inicializarConsultarPorLugar(DLugarPKTO pkLugar) {
		setTipoOperacion(CONSULTAR_POR_LUGAR);
		this.pkLugar = pkLugar;
	}

	/**
	 * Inicializa la consulta por Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	public void inicializarConsultarPorLugar(DLugarPKTO pkLugar) {
		setTipoOperacion(CONSULTAR_POR_LUGAR);
		this.pkLugar = pkLugar;
	}

	/**
	 * Inicializa la creaci�nn de Lugar.
	 * @param toLugar Objeto de Transporte de Lugar
	 */
	public void inicializarCrear(DLugarTO toLugar) {
		setTipoOperacion(CREAR);
		this.toLugar = toLugar;
		if (toLugar != null) {
			pkLugar = this.toLugar.getPK();
			attLugar = this.toLugar.getAtt();
		}
	}

	/**
	 * Inicializa la actualizaci�n de Lugar.
	 * @param toLugar Objeto de Transporte de Lugar
	 */
	public void inicializarActualizar(DLugarTO toLugar) {
		setTipoOperacion(ACTUALIZAR);
		this.toLugar = toLugar;
		if (toLugar != null) {
			pkLugar = this.toLugar.getPK();
			attLugar = this.toLugar.getAtt();
		}
	}

	/**
	 * Inicializa la eliminaci�n de Lugar.
	 * @param pkLugar Llave primaria de Lugar
	 */
	public void inicializarEliminar(DLugarPKTO pkLugar) {
		setTipoOperacion(ELIMINAR);
		this.pkLugar = pkLugar;
	}

	/**
	 * Inicializa la consulta gen�rica de Lugar.
	 * @param attLugar Atributos de Lugar
	 */
	public void inicializarConsultaGenerica(DLugarTO toLugar) {
		setTipoOperacion(CONSULTA_GENERICA);

		this.toLugar = toLugar;
		if (toLugar != null) {
			pkLugar = this.toLugar.getPK();
			attLugar = this.toLugar.getAtt();
		}
	}

	/**
	 * Devuelve las sentencias sql a ejecutar, dependiendo del tipo de operaci�n a realizar.
	 * @return Un Map de Strings con la relaci�n de sentencias sql
	 */
	public Map<String, String> getSentenciasSQL() {
		Map<String, String> m = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();
		switch (getTipoOperacion()) {
			case CREAR:
				sql.append("insert into LUGAR")
					.append(" (IDE_LUGAR, IDE_TIPO_LUGAR, IDE_LUGAR_PADRE, NOM_TIPO_LUGAR, IDE_USUARIO_CAMBIO, FEC_CAMBIO)")
					.append(" VALUES (:IDE_LUGAR, :IDE_TIPO_LUGAR, :IDE_LUGAR_PADRE, :NOM_TIPO_LUGAR, :IDE_USUARIO_CAMBIO, :FEC_CAMBIO)");
				m.put("sentencia1", sql.toString());
				break;
			case ACTUALIZAR:
				sql.append("update LUGAR")
					.append(" set IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR, IDE_LUGAR_PADRE=:IDE_LUGAR_PADRE, NOM_TIPO_LUGAR=:NOM_TIPO_LUGAR, IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO, FEC_CAMBIO=:FEC_CAMBIO")
					.append(" where IDE_LUGAR=:IDE_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case ELIMINAR:
				sql.append("delete from LUGAR")
					.append(" where IDE_LUGAR=:IDE_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_PK:
				sql.append("select * from LUGAR")
					.append(" where IDE_LUGAR=:IDE_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTA_GENERICA:
				sql.append("select * from LUGAR where ")
					.append(generarFiltroGenerico());
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_TIPOLUGAR:
				sql.append("select * from LUGAR")
					.append(" where IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_LUGAR:
				sql.append("select * from LUGAR")
					.append(" where ");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_LUGAR:
				sql.append("select * from LUGAR")
					.append(" where IDE_LUGAR=:IDE_LUGAR");
				m.put("sentencia1", sql.toString());
				break;
		}
		return m;
	}


	/**
	 * obtenerConsultaGenerica
	 *
	 * @return StringBuffer
	 */
	private String generarFiltroGenerico() {
		StringBuffer condiciones = new StringBuffer();
		String y = " AND ";
		boolean append = false;

		if (pkLugar != null) {

			if (pkLugar.getIdeLugar() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_LUGAR=:IDE_LUGAR");
				append = true;

			}
		}

		if (attLugar != null) {

			if (attLugar.getIdeTipoLugar() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_TIPO_LUGAR=:IDE_TIPO_LUGAR");
				append = true;

			}
			if (attLugar.getIdeLugarPadre() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_LUGAR_PADRE=:IDE_LUGAR_PADRE");
				append = true;

			}
			if (attLugar.getNomTipoLugar() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_TIPO_LUGAR=:NOM_TIPO_LUGAR");
				append = true;

			}
			if (attLugar.getIdeUsuarioCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO");
				append = true;

			}
			if (attLugar.getFecCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("FEC_CAMBIO=:FEC_CAMBIO");
				append = true;

			}
		}

		return condiciones.toString();
	}

	/**
	 * Asigna los valores no nulos de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresGenericos(DSentenciaSQL unaSentencia) throws SQLException {
		if (pkLugar != null) {
			if (pkLugar.getIdeLugar() != null) {
				unaSentencia.setInt("IDE_LUGAR", pkLugar.getIdeLugar());
			}
		}

		if (attLugar != null) {
			if (attLugar.getIdeTipoLugar() != null) {
				unaSentencia.setInt("IDE_TIPO_LUGAR", attLugar.getIdeTipoLugar());
			}
			if (attLugar.getIdeLugarPadre() != null) {
				unaSentencia.setInt("IDE_LUGAR_PADRE", attLugar.getIdeLugarPadre());
			}
			if (attLugar.getNomTipoLugar() != null) {
				unaSentencia.setString("NOM_TIPO_LUGAR", attLugar.getNomTipoLugar());
			}
			if (attLugar.getIdeUsuarioCambio() != null) {
				unaSentencia.setLong("IDE_USUARIO_CAMBIO", attLugar.getIdeUsuarioCambio());
			}
			if (attLugar.getFecCambio() != null) {
				unaSentencia.setTimestamp("FEC_CAMBIO", attLugar.getFecCambio());
			}
		}
	}

	/**
	 * Guarda los datos de Lugar.
	 * @return @return Un int con el n�mero de registros guardados
	 * @throws SQLException Si ocurre un error de base de datos al guardar
	 */
	public int guardar() throws SQLException {
		switch (getTipoOperacion()) {
			case CREAR:
				return crear();
			case ACTUALIZAR:
				return actualizar();
		}
		return -1;
	}

	/**
	 * Elimina registros de Lugar.
	 * @return Un int con el n�mero de registros eliminados
	 * @throws SQLException Si ocurre un error de base de datos al eliminar
	 */
	public int eliminar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		return sentencia.getRegistrosAfectados();
	}

	/**
	 * Consulta los datos de Lugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	public IDDataSet consultar() throws SQLException {
		switch (getTipoOperacion()) {
			case CONSULTAR_POR_PK:
				return consultarPorPK();
			case CONSULTAR_POR_TIPOLUGAR:
				return consultarPorTipoLugar();
			case CONSULTAR_POR_LUGAR:
				return consultarPorLugar();
			case CONSULTAR_POR_LUGAR:
				return consultarPorLugar();
			case CONSULTA_GENERICA:
				return consultaGenerica();
		}
		return null;
	}

	/**
	 * Crea un registro de Lugar.
	 * @return Un int con el n�mero de registros creados
	 * @throws SQLException Si ocurre un error de base de datos al crear
	 */
	private int crear() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha creado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� crear m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de Lugar.
	 * @return Un int con el n�mero de registros actualizados
	 * @throws SQLException Si ocurre un error de base de datos al actualizar
	 */
	private int actualizar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha actualizado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� actualizar m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de Lugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorPK() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarLugar(resultado);
		return resultado;
	}

	/**
	 * Consulta gen�rica de los datos de Lugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultaGenerica() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresGenericos(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosLugar(resultado);
		return resultado;
	}

	/**
	 * Consulta por TipoLugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorTipoLugar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		sentencia.setInt("IDE_TIPO_LUGAR", pkTipoLugar.getIdeTipoLugar());
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosLugar(resultado);
		return resultado;
	}

	/**
	 * Consulta por Lugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorLugar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosLugar(resultado);
		return resultado;
	}

	/**
	 * Consulta por Lugar.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorLugar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		sentencia.setInt("IDE_LUGAR", pkLugar.getIdeLugar());
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosLugar(resultado);
		return resultado;
	}

	/**
	 * Asigna los valores para pk en una sentencia SQL.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresPK(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setInt("IDE_LUGAR", pkLugar.getIdeLugar());
	}

	/**
	 * Asigna todos los valores de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresObjeto(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setInt("IDE_TIPO_LUGAR", attLugar.getIdeTipoLugar());
		unaSentencia.setInt("IDE_LUGAR_PADRE", attLugar.getIdeLugarPadre());
		unaSentencia.setString("NOM_TIPO_LUGAR", attLugar.getNomTipoLugar());
		unaSentencia.setLong("IDE_USUARIO_CAMBIO", attLugar.getIdeUsuarioCambio());
		unaSentencia.setTimestamp("FEC_CAMBIO", attLugar.getFecCambio());
	}

	/**
	 * Construye un objeto Lugar con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private void cargarLugar(IDDataSet resultado) throws SQLException {
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		toLugar = completarLugar(resultado);
	}

	/**
	 * Construye objetos Lugar con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar los objetos
	 */
	private void cargarObjetosLugar(IDDataSet resultado) throws SQLException {
		objetosLugar = new ArrayList<DLugarTO>();
		toLugar = null;
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		do {
			DLugarTO objeto = completarLugar(resultado);
			objetosLugar.add(objeto);
		} while (resultado.siguiente());
		resultado.primero();
	}

	/**
	 * Construye un objeto Lugar con base en el data set.
	 * El data set debe contener datos en la posici�n actual.
	 * @param resultado Contenedor de los datos
	 * @return Un Lugar
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private DLugarTO completarLugar(IDDataSet resultado) throws SQLException {
		// Conformar el objeto PK
		DLugarPKTO pk = new DLugarPKTO();
		//java.lang.Integer
		pk.setIdeLugar(resultado.getIntWrapper("IDE_LUGAR"));

		// Conformar el objeto Att
		DLugarAttTO att = new DLugarAttTO();
		//java.lang.Integer
		att.setIdeTipoLugar(resultado.getIntWrapper("IDE_TIPO_LUGAR"));
		//java.lang.Integer
if (resultado.getValorPorNombre("IDE_LUGAR_PADRE") != null) {
			att.setIdeLugarPadre(resultado.getIntWrapper("IDE_LUGAR_PADRE"));
		}
		//java.lang.String
		att.setNomTipoLugar(resultado.getString("NOM_TIPO_LUGAR"));
		//java.lang.Long
		att.setIdeUsuarioCambio(resultado.getLongWrapper("IDE_USUARIO_CAMBIO"));
		//java.sql.Timestamp
		att.setFecCambio((Timestamp)resultado.getValorPorNombre("FEC_CAMBIO"));

		// Conformar el TO
		DLugarTO to = new DLugarTO();
		to.setPK(pk);
		to.setAtt(att);
		return to;
	}

	/**
	 * Devuelve el objeto Lugar que se haya consultado.
	 * @return Un objeto DLugarTO
	 */
	public DLugarTO getLugar() {
		return toLugar;
	}

	/**
	 * Devuelve la colecci�n de objetos Lugar que se hayan consultado.
	 * @return Un Collection con objetos DLugarTO
	 */
	public Collection<DLugarTO> getColeccionLugar() {
		return objetosLugar;
	}

	/**
	 * Indica si el DAO es de ejecuci�n libre.
	 * @return true si es de ejecuci�n libre; false de lo contrario
	 */
	public boolean isEjecucionLibre() {
		return false;
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado por el administrador de persistencia.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 * @todo COMPLEMENTAR
	 */
	public boolean validar() throws DValidarExcepcion {
		DManipuladorMensaje manipulador;
		String operacion = null;
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (getTipoOperacion()) {
			case CREAR: operacion = "la creaci�n"; break;
			case ACTUALIZAR: operacion = "la actualizaci�n"; break;
			case ELIMINAR: operacion = "la eliminaci�n"; break;
			case CONSULTAR_POR_PK: operacion = "la consulta"; break;
			case CONSULTA_GENERICA: operacion = "la consulta"; break;
			case CONSULTAR_POR_TIPOLUGAR: operacion = "la consulta"; break;
			case CONSULTAR_POR_LUGAR: operacion = "la consulta"; break;
			case CONSULTAR_POR_LUGAR: operacion = "la consulta"; break;
		}

		if (operacion == null) {
			manipulador = new DManipuladorMensaje(IDArqMensajes.ME_OPER_INVALIDA);
			String mensaje = manipulador.getMensaje();
			throw new DValidarExcepcion(mensaje, mensaje);
		}

		if (tipoOperacion == CREAR || tipoOperacion == ACTUALIZAR) {
			parametros.put(this.getClass().getName()+":validar:toLugar",toLugar);
			parametros.put(this.getClass().getName()+":validar:pkLugar",pkLugar);
			parametros.put(this.getClass().getName()+":validar:attLugar",attLugar);

			parametros.put(this.getClass().getName()+":validar:pkLugar.getIdeLugar()",pkLugar.getIdeLugar());
			parametros.put(this.getClass().getName()+":validar:attLugar.getIdeTipoLugar()",attLugar.getIdeTipoLugar());
			parametros.put(this.getClass().getName()+":validar:attLugar.getNomTipoLugar()",attLugar.getNomTipoLugar());
			parametros.put(this.getClass().getName()+":validar:attLugar.getIdeUsuarioCambio()",attLugar.getIdeUsuarioCambio());
			parametros.put(this.getClass().getName()+":validar:attLugar.getFecCambio()",attLugar.getFecCambio());
		}

		if (tipoOperacion == CONSULTAR_POR_PK || tipoOperacion == ELIMINAR) {
			parametros.put(this.getClass().getName()+":validar:pkLugar",pkLugar);
			parametros.put(this.getClass().getName()+":validar:pkLugar.getIdeLugar()",pkLugar.getIdeLugar());
		}

		if (tipoOperacion == CONSULTA_GENERICA) {
			parametros.put(this.getClass().getName()+":validar:toLugar",toLugar);
		}

		if (tipoOperacion == CONSULTAR_POR_TIPOLUGAR) {
			parametros.put(this.getClass().getName()+":validar:pkTipoLugar.getIdeTipoLugar()",pkTipoLugar.getIdeTipoLugar());
		}
		if (tipoOperacion == CONSULTAR_POR_LUGAR) {
		}
		if (tipoOperacion == CONSULTAR_POR_LUGAR) {
			parametros.put(this.getClass().getName()+":validar:pkLugar.getIdeLugar()",pkLugar.getIdeLugar());
		}

		validarParametros(operacion,parametros);
		return true;
	}
}
