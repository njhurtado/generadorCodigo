/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.dao;

import java.sql.*;
import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyentePKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoDocumentoPKTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.general.persistencia.dao.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.dataset.*;
import co.gov.dian.muisca.arquitectura.mensajes.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;
import co.gov.dian.muisca.arquitectura.dao.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de acceso a datos para Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DDAOContribuyente extends DDAO implements IDDAOContribuyente {
	/** colecci�n de objetos DContribuyenteTO */
	private Collection<DContribuyenteTO> objetosContribuyente;
	/** Objeto de transporte de Contribuyente */
	private DContribuyenteTO toContribuyente;
	/** Llave primaria de Contribuyente */
	private DContribuyentePKTO pkContribuyente;
	/** Atributos de Contribuyente */
	private DContribuyenteAttTO attContribuyente;
	/** Llave primaria de TipoDocumento */
	private DTipoDocumentoPKTO pkTipoDocumento;

	/**
	 * Inicializa la consulta por llave primaria.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	public void inicializarConsultarPorPK(DContribuyentePKTO pkContribuyente) {
		setTipoOperacion(CONSULTAR_POR_PK);
		this.pkContribuyente = pkContribuyente;
	}

	/**
	 * Inicializa la consulta por TipoDocumento.
	 * @param pkTipoDocumento Llave primaria de TipoDocumento
	 */
	public void inicializarConsultarPorTipoDocumento(DTipoDocumentoPKTO pkTipoDocumento) {
		setTipoOperacion(CONSULTAR_POR_TIPODOCUMENTO);
		this.pkTipoDocumento = pkTipoDocumento;
	}

	/**
	 * Inicializa la creaci�nn de Contribuyente.
	 * @param toContribuyente Objeto de Transporte de Contribuyente
	 */
	public void inicializarCrear(DContribuyenteTO toContribuyente) {
		setTipoOperacion(CREAR);
		this.toContribuyente = toContribuyente;
		if (toContribuyente != null) {
			pkContribuyente = this.toContribuyente.getPK();
			attContribuyente = this.toContribuyente.getAtt();
		}
	}

	/**
	 * Inicializa la actualizaci�n de Contribuyente.
	 * @param toContribuyente Objeto de Transporte de Contribuyente
	 */
	public void inicializarActualizar(DContribuyenteTO toContribuyente) {
		setTipoOperacion(ACTUALIZAR);
		this.toContribuyente = toContribuyente;
		if (toContribuyente != null) {
			pkContribuyente = this.toContribuyente.getPK();
			attContribuyente = this.toContribuyente.getAtt();
		}
	}

	/**
	 * Inicializa la eliminaci�n de Contribuyente.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	public void inicializarEliminar(DContribuyentePKTO pkContribuyente) {
		setTipoOperacion(ELIMINAR);
		this.pkContribuyente = pkContribuyente;
	}

	/**
	 * Inicializa la consulta gen�rica de Contribuyente.
	 * @param attContribuyente Atributos de Contribuyente
	 */
	public void inicializarConsultaGenerica(DContribuyenteTO toContribuyente) {
		setTipoOperacion(CONSULTA_GENERICA);

		this.toContribuyente = toContribuyente;
		if (toContribuyente != null) {
			pkContribuyente = this.toContribuyente.getPK();
			attContribuyente = this.toContribuyente.getAtt();
		}
	}

	/**
	 * Devuelve las sentencias sql a ejecutar, dependiendo del tipo de operaci�n a realizar.
	 * @return Un Map de Strings con la relaci�n de sentencias sql
	 */
	public Map<String, String> getSentenciasSQL() {
		Map<String, String> m = new HashMap<String, String>();
		StringBuffer sql = new StringBuffer();
		switch (getTipoOperacion()) {
			case CREAR:
				sql.append("insert into CONTRIBUYENTE")
					.append(" (IDE_CONTRIBUYENTE, NOM_PRIMER_NOMBRE, NOM_OTROS_NOMBRES, NOM_PRIMER_APELLIDO, NOM_SEGUNDO_APELLIDO, NOM_RAZON_SOCIAL, IDE_TIPO_DOCUMENTO, NUM_IDENTIDAD, NUM_NIT, IDE_USUARIO_CAMBIO, FEC_CAMBIO)")
					.append(" VALUES (:IDE_CONTRIBUYENTE, :NOM_PRIMER_NOMBRE, :NOM_OTROS_NOMBRES, :NOM_PRIMER_APELLIDO, :NOM_SEGUNDO_APELLIDO, :NOM_RAZON_SOCIAL, :IDE_TIPO_DOCUMENTO, :NUM_IDENTIDAD, :NUM_NIT, :IDE_USUARIO_CAMBIO, :FEC_CAMBIO)");
				m.put("sentencia1", sql.toString());
				break;
			case ACTUALIZAR:
				sql.append("update CONTRIBUYENTE")
					.append(" set NOM_PRIMER_NOMBRE=:NOM_PRIMER_NOMBRE, NOM_OTROS_NOMBRES=:NOM_OTROS_NOMBRES, NOM_PRIMER_APELLIDO=:NOM_PRIMER_APELLIDO, NOM_SEGUNDO_APELLIDO=:NOM_SEGUNDO_APELLIDO, NOM_RAZON_SOCIAL=:NOM_RAZON_SOCIAL, IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO, NUM_IDENTIDAD=:NUM_IDENTIDAD, NUM_NIT=:NUM_NIT, IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO, FEC_CAMBIO=:FEC_CAMBIO")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE");
				m.put("sentencia1", sql.toString());
				break;
			case ELIMINAR:
				sql.append("delete from CONTRIBUYENTE")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_PK:
				sql.append("select * from CONTRIBUYENTE")
					.append(" where IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE");
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTA_GENERICA:
				sql.append("select * from CONTRIBUYENTE where ")
					.append(generarFiltroGenerico());
				m.put("sentencia1", sql.toString());
				break;
			case CONSULTAR_POR_TIPODOCUMENTO:
				sql.append("select * from CONTRIBUYENTE")
					.append(" where IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO");
				m.put("sentencia1", sql.toString());
				break;
		}
		return m;
	}


	/**
	 * obtenerConsultaGenerica
	 *
	 * @return StringBuffer
	 */
	private String generarFiltroGenerico() {
		StringBuffer condiciones = new StringBuffer();
		String y = " AND ";
		boolean append = false;

		if (pkContribuyente != null) {

			if (pkContribuyente.getIdeContribuyente() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_CONTRIBUYENTE=:IDE_CONTRIBUYENTE");
				append = true;

			}
		}

		if (attContribuyente != null) {

			if (attContribuyente.getNomPrimerNombre() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_PRIMER_NOMBRE=:NOM_PRIMER_NOMBRE");
				append = true;

			}
			if (attContribuyente.getNomOtrosNombres() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_OTROS_NOMBRES=:NOM_OTROS_NOMBRES");
				append = true;

			}
			if (attContribuyente.getNomPrimerApellido() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_PRIMER_APELLIDO=:NOM_PRIMER_APELLIDO");
				append = true;

			}
			if (attContribuyente.getNomSegundoApellido() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_SEGUNDO_APELLIDO=:NOM_SEGUNDO_APELLIDO");
				append = true;

			}
			if (attContribuyente.getNomRazonSocial() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NOM_RAZON_SOCIAL=:NOM_RAZON_SOCIAL");
				append = true;

			}
			if (attContribuyente.getIdeTipoDocumento() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_TIPO_DOCUMENTO=:IDE_TIPO_DOCUMENTO");
				append = true;

			}
			if (attContribuyente.getNumIdentidad() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NUM_IDENTIDAD=:NUM_IDENTIDAD");
				append = true;

			}
			if (attContribuyente.getNumNit() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("NUM_NIT=:NUM_NIT");
				append = true;

			}
			if (attContribuyente.getIdeUsuarioCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("IDE_USUARIO_CAMBIO=:IDE_USUARIO_CAMBIO");
				append = true;

			}
			if (attContribuyente.getFecCambio() != null) {
				if (append) {
					condiciones.append(y);
				}
				condiciones.append("FEC_CAMBIO=:FEC_CAMBIO");
				append = true;

			}
		}

		return condiciones.toString();
	}

	/**
	 * Asigna los valores no nulos de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresGenericos(DSentenciaSQL unaSentencia) throws SQLException {
		if (pkContribuyente != null) {
			if (pkContribuyente.getIdeContribuyente() != null) {
				unaSentencia.setInt("IDE_CONTRIBUYENTE", pkContribuyente.getIdeContribuyente());
			}
		}

		if (attContribuyente != null) {
			if (attContribuyente.getNomPrimerNombre() != null) {
				unaSentencia.setString("NOM_PRIMER_NOMBRE", attContribuyente.getNomPrimerNombre());
			}
			if (attContribuyente.getNomOtrosNombres() != null) {
				unaSentencia.setString("NOM_OTROS_NOMBRES", attContribuyente.getNomOtrosNombres());
			}
			if (attContribuyente.getNomPrimerApellido() != null) {
				unaSentencia.setString("NOM_PRIMER_APELLIDO", attContribuyente.getNomPrimerApellido());
			}
			if (attContribuyente.getNomSegundoApellido() != null) {
				unaSentencia.setString("NOM_SEGUNDO_APELLIDO", attContribuyente.getNomSegundoApellido());
			}
			if (attContribuyente.getNomRazonSocial() != null) {
				unaSentencia.setString("NOM_RAZON_SOCIAL", attContribuyente.getNomRazonSocial());
			}
			if (attContribuyente.getIdeTipoDocumento() != null) {
				unaSentencia.setInt("IDE_TIPO_DOCUMENTO", attContribuyente.getIdeTipoDocumento());
			}
			if (attContribuyente.getNumIdentidad() != null) {
				unaSentencia.setString("NUM_IDENTIDAD", attContribuyente.getNumIdentidad());
			}
			if (attContribuyente.getNumNit() != null) {
				unaSentencia.setLong("NUM_NIT", attContribuyente.getNumNit());
			}
			if (attContribuyente.getIdeUsuarioCambio() != null) {
				unaSentencia.setLong("IDE_USUARIO_CAMBIO", attContribuyente.getIdeUsuarioCambio());
			}
			if (attContribuyente.getFecCambio() != null) {
				unaSentencia.setTimestamp("FEC_CAMBIO", attContribuyente.getFecCambio());
			}
		}
	}

	/**
	 * Guarda los datos de Contribuyente.
	 * @return @return Un int con el n�mero de registros guardados
	 * @throws SQLException Si ocurre un error de base de datos al guardar
	 */
	public int guardar() throws SQLException {
		switch (getTipoOperacion()) {
			case CREAR:
				return crear();
			case ACTUALIZAR:
				return actualizar();
		}
		return -1;
	}

	/**
	 * Elimina registros de Contribuyente.
	 * @return Un int con el n�mero de registros eliminados
	 * @throws SQLException Si ocurre un error de base de datos al eliminar
	 */
	public int eliminar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		return sentencia.getRegistrosAfectados();
	}

	/**
	 * Consulta los datos de Contribuyente.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	public IDDataSet consultar() throws SQLException {
		switch (getTipoOperacion()) {
			case CONSULTAR_POR_PK:
				return consultarPorPK();
			case CONSULTAR_POR_TIPODOCUMENTO:
				return consultarPorTipoDocumento();
			case CONSULTA_GENERICA:
				return consultaGenerica();
		}
		return null;
	}

	/**
	 * Crea un registro de Contribuyente.
	 * @return Un int con el n�mero de registros creados
	 * @throws SQLException Si ocurre un error de base de datos al crear
	 */
	private int crear() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha creado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� crear m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de Contribuyente.
	 * @return Un int con el n�mero de registros actualizados
	 * @throws SQLException Si ocurre un error de base de datos al actualizar
	 */
	private int actualizar() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresObjeto(sentencia);
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		int resultado = sentencia.getRegistrosAfectados();
		if (resultado <= 0) {
			throw new SQLException("No se ha actualizado ning�n registro");
		}
		if (resultado > 1) {
			throw new SQLException("Se intent� actualizar m�s de un registro");
		}
		return resultado;
	}

	/**
	 * Actualiza los datos de Contribuyente.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorPK() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresPK(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarContribuyente(resultado);
		return resultado;
	}

	/**
	 * Consulta gen�rica de los datos de Contribuyente.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultaGenerica() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		asignarValoresGenericos(sentencia);
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosContribuyente(resultado);
		return resultado;
	}

	/**
	 * Consulta por TipoDocumento.
	 * @return Un IDDataSet con la colecci�n de registros encontrados
	 * @throws SQLException Si ocurre un error de base de datos al consultar
	 */
	private IDDataSet consultarPorTipoDocumento() throws SQLException {
		DSentenciaSQL sentencia = getSentenciaSQLPreparada("sentencia1");
		sentencia.setInt("IDE_TIPO_DOCUMENTO", pkTipoDocumento.getIdeTipoDocumento());
		sentencia.ejecutar();
		DDataSet resultado = sentencia.getDataSet();
		cargarObjetosContribuyente(resultado);
		return resultado;
	}

	/**
	 * Asigna los valores para pk en una sentencia SQL.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresPK(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setInt("IDE_CONTRIBUYENTE", pkContribuyente.getIdeContribuyente());
	}

	/**
	 * Asigna todos los valores de un objeto.
	 * @param unaSentencia Sentencia para asignaci�n
	 * @throws SQLException Si ocurre un error al asignar los valores
	 */
	private void asignarValoresObjeto(DSentenciaSQL unaSentencia) throws SQLException {
		unaSentencia.setString("NOM_PRIMER_NOMBRE", attContribuyente.getNomPrimerNombre());
		unaSentencia.setString("NOM_OTROS_NOMBRES", attContribuyente.getNomOtrosNombres());
		unaSentencia.setString("NOM_PRIMER_APELLIDO", attContribuyente.getNomPrimerApellido());
		unaSentencia.setString("NOM_SEGUNDO_APELLIDO", attContribuyente.getNomSegundoApellido());
		unaSentencia.setString("NOM_RAZON_SOCIAL", attContribuyente.getNomRazonSocial());
		unaSentencia.setInt("IDE_TIPO_DOCUMENTO", attContribuyente.getIdeTipoDocumento());
		unaSentencia.setString("NUM_IDENTIDAD", attContribuyente.getNumIdentidad());
		unaSentencia.setLong("NUM_NIT", attContribuyente.getNumNit());
		unaSentencia.setLong("IDE_USUARIO_CAMBIO", attContribuyente.getIdeUsuarioCambio());
		unaSentencia.setTimestamp("FEC_CAMBIO", attContribuyente.getFecCambio());
	}

	/**
	 * Construye un objeto Contribuyente con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private void cargarContribuyente(IDDataSet resultado) throws SQLException {
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		toContribuyente = completarContribuyente(resultado);
	}

	/**
	 * Construye objetos Contribuyente con base en el data set.
	 * @param resultado Contenedor de los datos
	 * @throws SQLException Si ocurre un error de base de datos al cargar los objetos
	 */
	private void cargarObjetosContribuyente(IDDataSet resultado) throws SQLException {
		objetosContribuyente = new ArrayList<DContribuyenteTO>();
		toContribuyente = null;
		if (resultado.getNumeroFilas() == 0) {
			return;
		}
		resultado.primero();
		do {
			DContribuyenteTO objeto = completarContribuyente(resultado);
			objetosContribuyente.add(objeto);
		} while (resultado.siguiente());
		resultado.primero();
	}

	/**
	 * Construye un objeto Contribuyente con base en el data set.
	 * El data set debe contener datos en la posici�n actual.
	 * @param resultado Contenedor de los datos
	 * @return Un Contribuyente
	 * @throws SQLException Si ocurre un error de base de datos al cargar el objeto
	 */
	private DContribuyenteTO completarContribuyente(IDDataSet resultado) throws SQLException {
		// Conformar el objeto PK
		DContribuyentePKTO pk = new DContribuyentePKTO();
		//java.lang.Integer
		pk.setIdeContribuyente(resultado.getIntWrapper("IDE_CONTRIBUYENTE"));

		// Conformar el objeto Att
		DContribuyenteAttTO att = new DContribuyenteAttTO();
		//java.lang.String
		att.setNomPrimerNombre(resultado.getString("NOM_PRIMER_NOMBRE"));
		//java.lang.String
		att.setNomOtrosNombres(resultado.getString("NOM_OTROS_NOMBRES"));
		//java.lang.String
		att.setNomPrimerApellido(resultado.getString("NOM_PRIMER_APELLIDO"));
		//java.lang.String
		att.setNomSegundoApellido(resultado.getString("NOM_SEGUNDO_APELLIDO"));
		//java.lang.String
		att.setNomRazonSocial(resultado.getString("NOM_RAZON_SOCIAL"));
		//java.lang.Integer
		att.setIdeTipoDocumento(resultado.getIntWrapper("IDE_TIPO_DOCUMENTO"));
		//java.lang.String
		att.setNumIdentidad(resultado.getString("NUM_IDENTIDAD"));
		//java.lang.Long
if (resultado.getValorPorNombre("NUM_NIT") != null) {
			att.setNumNit(resultado.getLongWrapper("NUM_NIT"));
		}
		//java.lang.Long
		att.setIdeUsuarioCambio(resultado.getLongWrapper("IDE_USUARIO_CAMBIO"));
		//java.sql.Timestamp
		att.setFecCambio((Timestamp)resultado.getValorPorNombre("FEC_CAMBIO"));

		// Conformar el TO
		DContribuyenteTO to = new DContribuyenteTO();
		to.setPK(pk);
		to.setAtt(att);
		return to;
	}

	/**
	 * Devuelve el objeto Contribuyente que se haya consultado.
	 * @return Un objeto DContribuyenteTO
	 */
	public DContribuyenteTO getContribuyente() {
		return toContribuyente;
	}

	/**
	 * Devuelve la colecci�n de objetos Contribuyente que se hayan consultado.
	 * @return Un Collection con objetos DContribuyenteTO
	 */
	public Collection<DContribuyenteTO> getColeccionContribuyente() {
		return objetosContribuyente;
	}

	/**
	 * Indica si el DAO es de ejecuci�n libre.
	 * @return true si es de ejecuci�n libre; false de lo contrario
	 */
	public boolean isEjecucionLibre() {
		return false;
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado por el administrador de persistencia.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 * @todo COMPLEMENTAR
	 */
	public boolean validar() throws DValidarExcepcion {
		DManipuladorMensaje manipulador;
		String operacion = null;
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (getTipoOperacion()) {
			case CREAR: operacion = "la creaci�n"; break;
			case ACTUALIZAR: operacion = "la actualizaci�n"; break;
			case ELIMINAR: operacion = "la eliminaci�n"; break;
			case CONSULTAR_POR_PK: operacion = "la consulta"; break;
			case CONSULTA_GENERICA: operacion = "la consulta"; break;
			case CONSULTAR_POR_TIPODOCUMENTO: operacion = "la consulta"; break;
		}

		if (operacion == null) {
			manipulador = new DManipuladorMensaje(IDArqMensajes.ME_OPER_INVALIDA);
			String mensaje = manipulador.getMensaje();
			throw new DValidarExcepcion(mensaje, mensaje);
		}

		if (tipoOperacion == CREAR || tipoOperacion == ACTUALIZAR) {
			parametros.put(this.getClass().getName()+":validar:toContribuyente",toContribuyente);
			parametros.put(this.getClass().getName()+":validar:pkContribuyente",pkContribuyente);
			parametros.put(this.getClass().getName()+":validar:attContribuyente",attContribuyente);

			parametros.put(this.getClass().getName()+":validar:pkContribuyente.getIdeContribuyente()",pkContribuyente.getIdeContribuyente());
			parametros.put(this.getClass().getName()+":validar:attContribuyente.getIdeTipoDocumento()",attContribuyente.getIdeTipoDocumento());
			parametros.put(this.getClass().getName()+":validar:attContribuyente.getIdeUsuarioCambio()",attContribuyente.getIdeUsuarioCambio());
			parametros.put(this.getClass().getName()+":validar:attContribuyente.getFecCambio()",attContribuyente.getFecCambio());
		}

		if (tipoOperacion == CONSULTAR_POR_PK || tipoOperacion == ELIMINAR) {
			parametros.put(this.getClass().getName()+":validar:pkContribuyente",pkContribuyente);
			parametros.put(this.getClass().getName()+":validar:pkContribuyente.getIdeContribuyente()",pkContribuyente.getIdeContribuyente());
		}

		if (tipoOperacion == CONSULTA_GENERICA) {
			parametros.put(this.getClass().getName()+":validar:toContribuyente",toContribuyente);
		}

		if (tipoOperacion == CONSULTAR_POR_TIPODOCUMENTO) {
			parametros.put(this.getClass().getName()+":validar:pkTipoDocumento.getIdeTipoDocumento()",pkTipoDocumento.getIdeTipoDocumento());
		}

		validarParametros(operacion,parametros);
		return true;
	}
}
