/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para la PK de TipoDocumento.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DTipoDocumentoPKTO implements IDTO {

	private static final long serialVersionUID = 1480578393L; 

  // Campos de la PK
	private java.lang.Integer ideTipoDocumento;

	/**
	 * Construye un nuevo DTipoDocumentoPKTO por defecto.
	 */
	public DTipoDocumentoPKTO() { }

	/**
	 * Construye un nuevo DTipoDocumentoPKTO con los elementos de la llave primaria.
	 * @param ideTipoDocumento java.lang.Integer
	 */
	public DTipoDocumentoPKTO(java.lang.Integer ideTipoDocumento) {
		setIdeTipoDocumento(ideTipoDocumento);
	}

	/**
	 * Devuelve el valor de ideTipoDocumento.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeTipoDocumento() {
		return ideTipoDocumento;
	}

	/**
	 * Establece el valor de ideTipoDocumento.
	 * @param ideTipoDocumento El nuevo valor de ideTipoDocumento
	 */
	public void setIdeTipoDocumento(java.lang.Integer ideTipoDocumento) {
		this.ideTipoDocumento = ideTipoDocumento;
	}

	/**
	 * Compara el objeto actual con el objeto especificado.
	 * @param objeto Objeto con el cual se compara
	 * @return true si los objetos son iguales; false de lo contrario
	 */
	public boolean equals(Object objeto) {
		if (this == objeto) {
			return true;
		}
		if (!(objeto instanceof DTipoDocumentoPKTO)) {
			return false;
		}
		DTipoDocumentoPKTO otro = (DTipoDocumentoPKTO) objeto;
		EqualsBuilder builder = new EqualsBuilder();
		builder.append(getIdeTipoDocumento(),  otro.getIdeTipoDocumento());
		return builder.isEquals();
	}

	/**
	 * Devuelve el hash code del objeto.
	 * @return int
	 */
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();
		builder.append(getIdeTipoDocumento());
		return builder.toHashCode();
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("ideTipoDocumento", getIdeTipoDocumento());
		return builder.toString();
	}
}
