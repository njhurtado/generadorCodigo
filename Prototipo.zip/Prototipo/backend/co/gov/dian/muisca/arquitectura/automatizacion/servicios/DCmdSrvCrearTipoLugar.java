/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.servicios;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarAttTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarPKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DTipoLugarTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de servicio utilizado para crear un objeto TipoLugar.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdSrvCrearTipoLugar extends DComandoServicioInterno {
	private static final long serialVersionUID = -2138098920L; 

	/** Objeto de transporte de TipoLugar */
	protected DTipoLugarTO toTipoLugar;
	/** Llave primaria de TipoLugar */
	protected DTipoLugarPKTO pkTipoLugar;
	/** Atributos de TipoLugar */
	protected DTipoLugarAttTO attTipoLugar;

	/**
	 * Inicializa la creaci�n de TipoLugar.
	 * @param toTipoLugar Objeto de Transporte de TipoLugar
	 */
	public void inicializar(DTipoLugarTO toTipoLugar) {
		this.toTipoLugar = toTipoLugar;
		if (toTipoLugar != null) {
			pkTipoLugar = this.toTipoLugar.getPK();
			attTipoLugar = this.toTipoLugar.getAtt();
		}
	}


	/**
	 * Ejecuta el comando de servicio.
	 * @throws DExcepcion Si ocurre alg�n error al realizar la
	 * la creaci�n de TipoLugar
	 */
	protected void ejecutarComando() throws DExcepcion {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdSrvCrearTipoLugar();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite crear un objeto TipoLugar";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�ndel comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put(this.getClass().getName()+":validar:toTipoLugar",toTipoLugar);
		parametros.put(this.getClass().getName()+":validar:attTipoLugar",attTipoLugar);
		parametros.put(this.getClass().getName()+":validar:pkTipoLugar",pkTipoLugar);
		parametros.put(this.getClass().getName()+":validar:pkTipoLugar.getIdeTipoLugar()",pkTipoLugar.getIdeTipoLugar());
		parametros.put(this.getClass().getName()+":validar:attTipoLugar.getNomTipoLugar()",attTipoLugar.getNomTipoLugar());
		parametros.put(this.getClass().getName()+":validar:attTipoLugar.getIdeUsuarioCambio()",attTipoLugar.getIdeUsuarioCambio());
		parametros.put(this.getClass().getName()+":validar:attTipoLugar.getFecCambio()",attTipoLugar.getFecCambio());
		validarParametros("Crear",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdSrvCrearTipoLugar) {
			DCmdSrvCrearTipoLugar copia = (DCmdSrvCrearTipoLugar) comando;
			copia.toTipoLugar = toTipoLugar;
			copia.pkTipoLugar = pkTipoLugar;
			copia.attTipoLugar = attTipoLugar;
		}
	}
}
