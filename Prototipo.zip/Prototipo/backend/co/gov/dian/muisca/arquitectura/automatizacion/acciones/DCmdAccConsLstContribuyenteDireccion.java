/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import java.util.*;

import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyenteDireccionTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DContribuyentePKTO;
import co.gov.dian.muisca.arquitectura.automatizacion.general.to.DDireccionPKTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.interfaces.*;
import co.gov.dian.muisca.arquitectura.interfaces.implgenerica.comandos.*;
import co.gov.dian.muisca.arquitectura.general.to.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar objetos ContribuyenteDireccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsLstContribuyenteDireccion extends DComandoAccion {
	private static final long serialVersionUID = -1635429577L; 
	
	public static final int CONSULTAR_POR_CONTRIBUYENTE = 0;
	public static final int CONSULTAR_POR_DIRECCION = 1;

	protected static final int CONSULTA_GENERICA = 2;

	/** Llave primaria de Contribuyente */
	protected DContribuyentePKTO pkContribuyente;
	/** Llave primaria de Direccion */
	protected DDireccionPKTO pkDireccion;

	protected DContribuyenteDireccionTO toContribuyenteDireccion;


	/** Tipo de operaci�n de consulta */
	protected int tipoOperacion = -1;
	/** Colecci�n de objetos DContribuyenteDireccionTO */
	protected Collection<DContribuyenteDireccionTO> objetosContribuyenteDireccion;

	/**
	 * Inicializa la consulta por Contribuyente.
	 * @param pkContribuyente Llave primaria de Contribuyente
	 */
	public void inicializarConsultarPorContribuyente(DContribuyentePKTO pkContribuyente) {
		isOk = false;
		tipoOperacion = CONSULTAR_POR_CONTRIBUYENTE;
		this.pkContribuyente = pkContribuyente;
		objetosContribuyenteDireccion = null;
	}

	/**
	 * Inicializa la consulta por Direccion.
	 * @param pkDireccion Llave primaria de Direccion
	 */
	public void inicializarConsultarPorDireccion(DDireccionPKTO pkDireccion) {
		isOk = false;
		tipoOperacion = CONSULTAR_POR_DIRECCION;
		this.pkDireccion = pkDireccion;
		objetosContribuyenteDireccion = null;
	}


	/**
	 * Inicializa la consulta gen�rica de ContribuyenteDireccion.
	 * @param attContribuyenteDireccion Atributos de ContribuyenteDireccion
	 */
	public void inicializarConsultaGenerica(DContribuyenteDireccionTO toContribuyenteDireccion) {
		tipoOperacion = CONSULTA_GENERICA;
		this.toContribuyenteDireccion = toContribuyenteDireccion;

	}

	/**
	 * Devuelve la colecci�n de objetos ContribuyenteDireccion que se hayan consultado.
	 * @return Un Collection con objetos DContribuyenteDireccionTO
	 */
	public Collection<DContribuyenteDireccionTO> getColeccionContribuyenteDireccion() {
		return objetosContribuyenteDireccion;
	}

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtiene una copia (clon) del comando.
	 * @return Un Object con la copia del comando
	 */
	public Object clonar() {
		return new DCmdAccConsLstContribuyenteDireccion();
	}

	/**
	 * Indica si el comando es auditable.
	 * @return true si el comando es auditable; false de lo contrario
	 */
	public boolean isAuditable() {
		return true;
	}

	/**
	 * Obtiene la descripci�n del comando.
	 * @return Un String con la descripci�n del comando
	 */
	public String getDescripcion() {
		return "Permite consultar objetos ContribuyenteDireccion";
	}

	/**
	 * M�todo para validar los par�metros inicializados, invocado
	 * previamente a la ejecuci�n del comando.
	 * @return true si los par�metros son v�lidos; false de lo contrario
	 * @throws DValidarExcepcion Si los par�metros no son v�lidos
	 */
	public boolean validar() throws DValidarExcepcion {
		Map<String, Object> parametros=new HashMap<String, Object>();
		switch (tipoOperacion) {
			case CONSULTAR_POR_CONTRIBUYENTE:
				parametros.put(this.getClass().getName()+":validar:pkContribuyente",pkContribuyente);
				parametros.put(this.getClass().getName()+":validar:pkContribuyente.getIdeContribuyente()",pkContribuyente.getIdeContribuyente());
				break;
			case CONSULTAR_POR_DIRECCION:
				parametros.put(this.getClass().getName()+":validar:pkDireccion",pkDireccion);
				parametros.put(this.getClass().getName()+":validar:pkDireccion.getIdeDireccion()",pkDireccion.getIdeDireccion());
				break;

			case CONSULTA_GENERICA:
				parametros.put(this.getClass().getName()+":validar:toContribuyenteDireccion",toContribuyenteDireccion);
				break;


			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos ContribuyenteDireccion"), getMensajeOperInvalida());
		}
		validarParametros("Listar",parametros);
		return true;
	}

	/**
	 * Para copiar el contenido del comando actual al comando enviado como par�metro.
	 * @param comando Comando sobre el cual copiar
	 */
	public void asignar(IDComando comando) {
		if (comando instanceof DCmdAccConsLstContribuyenteDireccion) {
			DCmdAccConsLstContribuyenteDireccion copia = (DCmdAccConsLstContribuyenteDireccion) comando;
			copia.tipoOperacion = tipoOperacion;
			copia.pkContribuyente = pkContribuyente;
			copia.pkDireccion = pkDireccion;
			copia.objetosContribuyenteDireccion = objetosContribuyenteDireccion;
			copia.toContribuyenteDireccion = toContribuyenteDireccion;
		}
	}
}
