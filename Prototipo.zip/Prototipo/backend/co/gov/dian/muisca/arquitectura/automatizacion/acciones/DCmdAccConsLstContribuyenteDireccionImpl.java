/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.acciones;

import co.gov.dian.muisca.arquitectura.automatizacion.servicios.DCmdSrvConsLstContribuyenteDireccion;
import co.gov.dian.muisca.arquitectura.general.excepcion.*;
import co.gov.dian.muisca.arquitectura.servicios.automatizacion.*;
import co.gov.dian.muisca.arquitectura.acciones.automatizacion.*;

/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Comando de acci�n utilizado para consultar objetos ContribuyenteDireccion.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DCmdAccConsLstContribuyenteDireccionImpl extends DCmdAccConsLstContribuyenteDireccion {
	private static final long serialVersionUID = -1561175541L; 

	/**
	 * Ejecuta el comando de acci�n.
	 */
	protected void ejecutarComando() {
		try {
			DCmdSrvConsLstContribuyenteDireccion servicio = (DCmdSrvConsLstContribuyenteDireccion) getServicio("arquitectura.automatizacion.DCmdSrvConsLstContribuyenteDireccion");
			servicio.setPaginable(true);
			switch (tipoOperacion) {
			case CONSULTAR_POR_CONTRIBUYENTE:
				servicio.inicializarConsultarPorContribuyente(pkContribuyente);
				break;
			case CONSULTAR_POR_DIRECCION:
				servicio.inicializarConsultarPorDireccion(pkDireccion);
				break;

			case CONSULTA_GENERICA:
				servicio.inicializarConsultaGenerica(toContribuyenteDireccion);
				break;


			default:
				throw new DValidarExcepcion(getMensajeGeneral("la consulta", "de objetos ContribuyenteDireccion"), getMensajeOperInvalida());
			}
			servicio.ejecutar();
			objetosContribuyenteDireccion = servicio.getColeccionContribuyenteDireccion();
			isOk = true;
		}
		catch (DExcepcion ex) {
			mensajeError = ex.getMessage();
			mensajeErrorDetallado = ex.getMensajeDetallado();
			isOk = false;
		}
	}
}
