/**
 * Republica de Colombia
 * Copyright (c) 2004 Direcci�n de Impuestos y Aduanas Nacionales.
 * (DIAN - www.dian.gov.co).  Todos los Derechos reservados.
 *
 * $Header:$
 */
package co.gov.dian.muisca.arquitectura.automatizacion.general.to;

import co.gov.dian.muisca.arquitectura.general.to.IDTO;
import org.apache.commons.lang.builder.*;


/**
 * <p>Titulo: Proyecto MUISCA</p>
 * <p>Descripcion: Objeto de transporte para la PK de Contribuyente.</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: DIAN</p>
 *
 * @author Nelson Hurtado
 * @version $Revision:$
 * <pre>
 * $Log[10]:$
 * </pre>
 */
public class DContribuyentePKTO implements IDTO {

	private static final long serialVersionUID = 1834524729L; 

  // Campos de la PK
	private java.lang.Integer ideContribuyente;

	/**
	 * Construye un nuevo DContribuyentePKTO por defecto.
	 */
	public DContribuyentePKTO() { }

	/**
	 * Construye un nuevo DContribuyentePKTO con los elementos de la llave primaria.
	 * @param ideContribuyente java.lang.Integer
	 */
	public DContribuyentePKTO(java.lang.Integer ideContribuyente) {
		setIdeContribuyente(ideContribuyente);
	}

	/**
	 * Devuelve el valor de ideContribuyente.
	 * @return Un objeto java.lang.Integer
	 */
	public java.lang.Integer getIdeContribuyente() {
		return ideContribuyente;
	}

	/**
	 * Establece el valor de ideContribuyente.
	 * @param ideContribuyente El nuevo valor de ideContribuyente
	 */
	public void setIdeContribuyente(java.lang.Integer ideContribuyente) {
		this.ideContribuyente = ideContribuyente;
	}

	/**
	 * Compara el objeto actual con el objeto especificado.
	 * @param objeto Objeto con el cual se compara
	 * @return true si los objetos son iguales; false de lo contrario
	 */
	public boolean equals(Object objeto) {
		if (this == objeto) {
			return true;
		}
		if (!(objeto instanceof DContribuyentePKTO)) {
			return false;
		}
		DContribuyentePKTO otro = (DContribuyentePKTO) objeto;
		EqualsBuilder builder = new EqualsBuilder();
		builder.append(getIdeContribuyente(),  otro.getIdeContribuyente());
		return builder.isEquals();
	}

	/**
	 * Devuelve el hash code del objeto.
	 * @return int
	 */
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();
		builder.append(getIdeContribuyente());
		return builder.toHashCode();
	}

	/**
	 * Devuelve una representaci�n en String del objeto.
	 * @return String
	 */
	public String toString() {
		ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("ideContribuyente", getIdeContribuyente());
		return builder.toString();
	}
}
