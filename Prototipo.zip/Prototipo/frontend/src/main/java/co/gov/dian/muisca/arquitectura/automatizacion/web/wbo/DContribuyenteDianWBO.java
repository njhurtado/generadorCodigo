package co.gov.dian.muisca.arquitectura.automatizacion.web.wbo;

import co.gov.dian.muisca.arquitectura.automatizacion.delegados.DCatalogoDelegados;
import co.gov.dian.muisca.arquitectura.automatizacion.web.general.to.generico.DAuditoriaWebDTO;
import co.gov.dian.muisca.arquitectura.general.excepcion.DMuiscaAppException;
import co.gov.dian.muisca.arquitectura.general.to.gdto.DGenericoDTO;

import javax.annotation.PostConstruct;
import javax.faces.model.SelectItem;
import java.util.List;

/**
 * @author hortizr
 * @version 1.0
 * @created 13-sept.-2018 12:53:28 p.m.
 */
public class DContribuyenteDianWBO extends DContribuyenteDianBaseWBO {

    private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger( DContribuyenteDianWBO.class );

    //Delegado Auditoria
    private DDelegadoNegocioContribuyente delegadoContribuyente;
    private DGenericoDTO dto;
    private DAuditoriaWebDTO dtoWeb;

    private List<SelectItem> tiposIdentList;

    //Datos del Contribuyente consultado
    private Long idPersonaRut;
    private Long idTipoDocumento;
    private String tipoDocumento;
    private Long numNit;
    private String nomRazonSocial;
    private String direccion;

    //Llave de Ubicacion de funcionario

    private Boolean verCardUsuario;

    public DContribuyenteDianWBO( ) {
        super( );
    }

    @PostConstruct
    public void init( ) {

        // Instanciacion del Delegado
        delegadoContribuyente = ( DDelegadoNegocioContribuyente )DCatalogoDelegados.DELEGADO_CONTRIBUYENTE.getInstancia( this.getContextoSeguridad( ), this.getNombreCmdProtector( ), this.getPkSegmentoAplicacion( ) );
        //DTO - Generico
        dto = new DGenericoDTO( "DContribuyenteDTO" );
        this.buscarTiposDocumentos( );

    }

    private void buscarTiposDocumentos( ) {
        try {
            //Se crea un objeto generico de capa web
            dtoWeb = new DAuditoriaWebDTO( delegadoContribuyente.buscarTiposDocumentos( dto ) );
            this.setTiposIdentList( dtoWeb.getSelectItemValorDominioList( "tiposIdentList" ) );

        }
        catch( DMuiscaAppException ex ) {
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            // Manejo de Mensajes de excepcion a nivel de logger
            this.notificarNoUsuarios( ex );
        }
    }

    public void buscarContribuyente( ) {

        logger.debug( "************  Buscar Contribuyente WBO ***********************" );

        // Datos del Filtro
        dto.addLong( "idTipoDocumento", this.idTipoDocumento );
        dto.addLong( "numNit", this.numNit );

        //Se busca el valor seleccionado del Combo - nominal
        this.tipoDocumento = dtoWeb.obtenerSeleccionadoCombox( "tiposIdentList", Integer.valueOf( this.idTipoDocumento.toString( ) ) );
        dto.addString( "tipoDocumento", this.tipoDocumento );

        try {

            dto = delegadoContribuyente.buscarContribuyente( dto );

            //Datos Base de Datos
            this.idPersonaRut = dto.getLongValue( "idPersonaRut" );
            this.idTipoDocumento = dto.getLongValue( "idTipoDocumento" );
            this.numNit = dto.getLongValue( "numNit" );
            this.nomRazonSocial = dto.getStringValue( "nomRazonSocial" );
            logger.debug( "idPersonaRut : " + this.idPersonaRut );
            logger.debug( "nomRazonSocial : " + this.nomRazonSocial );
            this.verCardUsuario = Boolean.TRUE;
        }
        catch( DMuiscaAppException ex ) {

            this.verCardUsuario = Boolean.FALSE;
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            this.notificarNoUsuarios( ex );
        }

    }

    public void crearContribuyentes( ) {

        logger.debug( "************  Crear Contribuyente WBO ***********************" );

        // Datos del Filtro
        dto.addLong( "idPersonaRut", this.idPersonaRut );
        dto.addLong( "idTipoDocumento", this.idTipoDocumento );
        dto.addLong( "numNit", this.numNit );
        dto.addString( "nomRazonSocial", this.nomRazonSocial );


        //Se busca el valor seleccionado del Combo - nominal
        this.tipoDocumento = dtoWeb.obtenerSeleccionadoCombox( "tiposIdentList", Integer.valueOf( this.idTipoDocumento.toString( ) ) );
        dto.addString( "tipoDocumento", this.tipoDocumento );

        try {

            dto = delegadoContribuyente.crearContribuyenteMuisca( dto );


        }
        catch( DMuiscaAppException ex ) {

            this.verCardUsuario = Boolean.FALSE;
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            this.notificarNoUsuarios( ex );
        }

    }

    public void actualizarContribuyente( ) {

        logger.debug( "************  Actualizar Contribuyente WBO ***********************" );
        // Datos del Filtro
        dto.addLong( "idPersonaRut", this.idPersonaRut );
        dto.addLong( "idTipoDocumento", this.idTipoDocumento );
        dto.addLong( "numNit", this.numNit );
        dto.addString( "nomRazonSocial", this.nomRazonSocial );

        //Se busca el valor seleccionado del Combo - nominal
        this.tipoDocumento = dtoWeb.obtenerSeleccionadoCombox( "tiposIdentList", Integer.valueOf( this.idTipoDocumento.toString( ) ) );
        dto.addString( "tipoDocumento", this.tipoDocumento );

        try {
            dto = delegadoContribuyente.actualizarContribuyenteMuisca( dto );
        }
        catch( DMuiscaAppException ex ) {

            this.verCardUsuario = Boolean.FALSE;
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            this.notificarNoUsuarios( ex );
        }

    }

    public void borrarContribuyente( ) {

        logger.debug( "************  Borrar Contribuyente WBO ***********************" );

        // Datos del Filtro
        dto.addLong( "idTipoDocumento", this.idTipoDocumento );
        dto.addLong( "numNit", this.numNit );

        //Se busca el valor seleccionado del Combo - nominal
        this.tipoDocumento = dtoWeb.obtenerSeleccionadoCombox( "tiposIdentList", Integer.valueOf( this.idTipoDocumento.toString( ) ) );
        dto.addString( "tipoDocumento", this.tipoDocumento );

        try {

            dto = delegadoContribuyente.borrarContribuyenteMuisca( dto );

        }
        catch( DMuiscaAppException ex ) {
            this.verCardUsuario = Boolean.FALSE;
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            this.notificarNoUsuarios( ex );
        }

    }

    public void borrarDireccionContribuyente( ) {

        logger.debug( "************  Borrar Direccion Contribuyente WBO ***********************" );

        // Datos del Filtro
        dto.addLong( "idTipoDocumento", this.idTipoDocumento );
        dto.addLong( "numNit", this.numNit );

        //Se busca el valor seleccionado del Combo - nominal
        this.tipoDocumento = dtoWeb.obtenerSeleccionadoCombox( "tiposIdentList", Integer.valueOf( this.idTipoDocumento.toString( ) ) );
        dto.addString( "tipoDocumento", this.tipoDocumento );

        try {

            dto = delegadoContribuyente.borrarDireccionContribuyenteMuisca( dto );

        }
        catch( DMuiscaAppException ex ) {
            this.verCardUsuario = Boolean.FALSE;
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            this.notificarNoUsuarios( ex );
        }

    }

    public void actualizarDireccionContribuyente( ) {

        logger.debug( "************  Actualizar Contribuyente WBO ***********************" );
        // Datos del Filtro
        dto.addLong( "idPersonaRut", this.idPersonaRut );
        dto.addLong( "idTipoDocumento", this.idTipoDocumento );
        dto.addLong( "numNit", this.numNit );
        dto.addString( "nomRazonSocial", this.nomRazonSocial );

        //Se busca el valor seleccionado del Combo - nominal
        this.tipoDocumento = dtoWeb.obtenerSeleccionadoCombox( "tiposIdentList", Integer.valueOf( this.idTipoDocumento.toString( ) ) );
        dto.addString( "tipoDocumento", this.tipoDocumento );

        try {
            dto = delegadoContribuyente.actualizarContribuyenteMuisca( dto );
        }
        catch( DMuiscaAppException ex ) {

            this.verCardUsuario = Boolean.FALSE;
            //Se decide el manejo de la excepcion propagada
            //Manejo de mensajes de excepcion a nivel de JavaServerFaces
            this.notificarUsuarios( ex );
            this.notificarNoUsuarios( ex );
        }

    }

    // --- Getters y Setters

    public Long getIdTipoDocumento( ) {
        return idTipoDocumento;
    }
    public void setIdTipoDocumento( Long idTipoDocumento ) {
        this.idTipoDocumento = idTipoDocumento;
    }
    public Long getNumNit( ) {
        return numNit;
    }
    public void setNumNit( Long numNit ) {
        this.numNit = numNit;
    }
    public String getNomRazonSocial( ) {
        return nomRazonSocial;
    }
    public void setNomRazonSocial( String nomRazonSocial ) {
        this.nomRazonSocial = nomRazonSocial;
    }

    public List<SelectItem> getTiposIdentList( ) {
        return tiposIdentList;
    }
    private void setTiposIdentList( List<SelectItem> tiposIdentList ) {
        this.tiposIdentList = tiposIdentList;
    }

    public Boolean getVerCardUsuario( ) {
        return verCardUsuario;
    }
    public void setVerCardUsuario( Boolean verCardUsuario ) {
        this.verCardUsuario = verCardUsuario;
    }

    public String getTipoDocumento( ) {
        return tipoDocumento;
    }
    public void setTipoDocumento( String tipoDocumento ) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getDireccion( ) {
        return direccion;
    }
    public void setDireccion( String direccion ) {
        this.direccion = direccion;
    }
}







