package co.gov.dian.muisca.arquitectura.automatizacion.web.wbo;

import co.gov.dian.muisca.arquitectura.general.excepcion.DMuiscaAppException;
import co.gov.dian.muisca.arquitectura.general.excepcion.errores.DErrorInfoBase;
import co.gov.dian.muisca.arquitectura.general.excepcion.errores.tipos.DConfirmacionErrorInfo;
import co.gov.dian.muisca.arquitectura.general.excepcion.errores.tipos.DValidacionWebErrorInfo;
import co.gov.dian.muisca.arquitectura.general.web.DWbo;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

public class DContribuyenteDianBaseWBO extends DWbo {

    private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger( DContribuyenteDianBaseWBO.class );

    //------------ Manejo de Excepciones Propagadas-----------------------------------------

    protected void notificarUsuarios( Throwable ex ) {
        if( ex instanceof DMuiscaAppException ) {
            DMuiscaAppException muiscaException = ( DMuiscaAppException )ex;

            if( muiscaException.getLastError( ) instanceof DValidacionWebErrorInfo ) {
                FacesContext.getCurrentInstance( ).addMessage( null, construirMensajeErrorFaces( muiscaException.getLastError( ) ) );
            }
            else if( muiscaException.getLastError( ) instanceof DConfirmacionErrorInfo ) {
                FacesContext.getCurrentInstance( ).addMessage( null, construirMensajeConfirmacionFaces( muiscaException.getLastError( ) ) );
            }

        }
    }

    protected void notificarNoUsuarios( Throwable ex ) {
        if( ex instanceof DMuiscaAppException ) {
            DMuiscaAppException ae = ( DMuiscaAppException )ex;
            for( DErrorInfoBase error : ae.getErrors( ) ) {
                logger.debug( "Severidad :" + error.getSeverity( ).name( ) );
                logger.debug( "Descripci�n :" + error.getErrorText( ) );
                logger.debug( "C�digo Error :" + error.getCode( ).getMessageCode( ) );
                logger.debug( "Par�metros :" + error.getParameters( ).toString( ) );
                error.getCause( ).printStackTrace( );
            }
        }
    }

    private FacesMessage construirMensajeErrorFaces( DErrorInfoBase errorInfo ) {
        logger.debug( "Severidad : " + errorInfo.getSeverity( ).name( ) );
        return new FacesMessage( FacesMessage.SEVERITY_ERROR, errorInfo.getSeverity( ).name( ), errorInfo.getErrorText( ) );
    }

    private FacesMessage construirMensajeConfirmacionFaces( DErrorInfoBase errorInfo ) {
        logger.debug( "Severidad : " + errorInfo.getSeverity( ).name( ) );
        return new FacesMessage( FacesMessage.SEVERITY_INFO, errorInfo.getSeverity( ).name( ), errorInfo.getErrorText( ) );
    }

}
