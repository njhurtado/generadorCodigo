package co.gov.dian.muisca.arquitectura.automatizacion.web.general.to.generico;

import co.gov.dian.muisca.arquitectura.general.to.gdto.DGenericoDTO;
import co.gov.dian.muisca.arquitectura.web.jsf.util.to.DGenericoWebDTO;

public class DAuditoriaWebDTO extends DGenericoWebDTO {

    private static final long serialVersionUID = -3920224824520595894L;
    public DAuditoriaWebDTO( String name ) {
        super( name );
    }

    public DAuditoriaWebDTO( DGenericoDTO genericoDTO ) {
        super( genericoDTO );

    }

}
